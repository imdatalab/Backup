# ============================================================
# STEP 3: Multivariable Logistic Regression
# Dataset: Alzheimer's Disease Dataset (n=2,149)
# Purpose: Identify independent predictors of Alzheimer's
#          after mutual adjustment (aOR with 95% CI)
# Models:  (A) Standard multivariable logistic regression
#          (B) LASSO-penalized logistic regression
# Standards: STROBE checklist, EPV ≥ 10 verified
# ============================================================

# ── 0. 라이브러리 ─────────────────────────────────────────
import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import Patch
import seaborn as sns
from scipy import stats

# Scikit-learn
from sklearn.linear_model import LogisticRegression, LogisticRegressionCV
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score, classification_report
from sklearn.model_selection import StratifiedKFold, cross_val_score

# Statsmodels (p-value, CI 계산)
import statsmodels.api as sm
import statsmodels.formula.api as smf

SEED = 42
np.random.seed(SEED)

COLORS = {
    'primary'  : '#0072B2',
    'positive' : '#D55E00',
    'negative' : '#009E73',
    'ns'       : '#999999',
    'lasso'    : '#CC79A7',
}

plt.rcParams.update({
    'font.family'      : 'DejaVu Sans',
    'font.size'        : 10,
    'axes.spines.top'  : False,
    'axes.spines.right': False,
    'figure.dpi'       : 150,
    'savefig.dpi'      : 300,
    'savefig.bbox'     : 'tight',
    'savefig.facecolor': 'white',
})

# ── 1. 데이터 로드 ─────────────────────────────────────────
print("=" * 60)
print("STEP 3: MULTIVARIABLE LOGISTIC REGRESSION")
print("=" * 60)

try:
    df = pd.read_csv('alzheimers.csv')
    print(f"[OK] 데이터 로드: {df.shape}")
except FileNotFoundError:
    print("[INFO] 시뮬레이션 데이터 생성")
    np.random.seed(SEED)
    n = 2149
    diag = np.random.choice([0,1], n, p=[0.647, 0.353])
    df = pd.DataFrame({
        'Age': np.where(diag==1,
                        np.random.normal(78,8,n),
                        np.random.normal(73,9,n)).clip(60,90).astype(int),
        'Gender': np.random.randint(0,2,n),
        'Ethnicity': np.random.choice([0,1,2,3],n),
        'EducationLevel': np.random.choice([0,1,2,3],n),
        'BMI': np.random.uniform(15,40,n),
        'Smoking': np.random.randint(0,2,n),
        'AlcoholConsumption': np.random.uniform(0,20,n),
        'PhysicalActivity': np.random.uniform(0,10,n),
        'DietQuality': np.random.uniform(0,10,n),
        'SleepQuality': np.random.uniform(4,10,n),
        'FamilyHistoryAlzheimers': np.random.randint(0,2,n),
        'CardiovascularDisease': np.random.randint(0,2,n),
        'Diabetes': np.random.randint(0,2,n),
        'Depression': np.random.randint(0,2,n),
        'HeadInjury': np.random.randint(0,2,n),
        'Hypertension': np.random.randint(0,2,n),
        'SystolicBP': np.random.randint(90,180,n),
        'DiastolicBP': np.random.randint(60,120,n),
        'CholesterolTotal': np.random.uniform(150,300,n),
        'CholesterolLDL': np.random.uniform(50,200,n),
        'CholesterolHDL': np.random.uniform(20,100,n),
        'CholesterolTriglycerides': np.random.uniform(50,400,n),
        'MMSE': np.where(diag==1,
                         np.random.normal(10,6,n).clip(0,30),
                         np.random.normal(20,5,n).clip(0,30)),
        'FunctionalAssessment': np.where(diag==1,
                         np.random.normal(3.5,2,n).clip(0,10),
                         np.random.normal(6.5,2,n).clip(0,10)),
        'MemoryComplaints': np.where(diag==1,
                         np.random.binomial(1,0.6,n),
                         np.random.binomial(1,0.15,n)),
        'BehavioralProblems': np.random.randint(0,2,n),
        'ADL': np.where(diag==1,
                         np.random.normal(3,2,n).clip(0,10),
                         np.random.normal(7,2,n).clip(0,10)),
        'Confusion': np.random.randint(0,2,n),
        'Disorientation': np.random.randint(0,2,n),
        'PersonalityChanges': np.random.randint(0,2,n),
        'DifficultyCompletingTasks': np.random.randint(0,2,n),
        'Forgetfulness': np.random.randint(0,2,n),
        'Diagnosis': diag,
    })

DROP = ['PatientID', 'DoctorInCharge']
df   = df.drop(columns=DROP, errors='ignore')
TARGET = 'Diagnosis'

# ── 2. 분석 변수 정의 ──────────────────────────────────────
# 모든 예측 변수 포함 (단변량에서 선별된 변수 기반)
ALL_PREDICTORS = [c for c in df.columns if c != TARGET]

# EPV(Events per Variable) 확인
n_events = df[TARGET].sum()
n_vars   = len(ALL_PREDICTORS)
epv      = n_events / n_vars
print(f"\nEPV 확인: {n_events}/{n_vars} = {epv:.1f} (권장 ≥ 10)")

# ── 3. 전처리 ──────────────────────────────────────────────
X = df[ALL_PREDICTORS].copy()
y = df[TARGET].copy()

# 연속형 변수 표준화 (z-score) — OR 해석을 위해 별도 보관
CONTINUOUS_VARS = [
    'Age','BMI','AlcoholConsumption','PhysicalActivity',
    'DietQuality','SleepQuality','SystolicBP','DiastolicBP',
    'CholesterolTotal','CholesterolLDL','CholesterolHDL',
    'CholesterolTriglycerides','MMSE','FunctionalAssessment','ADL'
]
scaler  = StandardScaler()
X_scaled = X.copy()
X_scaled[CONTINUOUS_VARS] = scaler.fit_transform(X[CONTINUOUS_VARS])

print(f"\n예측 변수: {len(ALL_PREDICTORS)}개")
print(f"결과변수: {TARGET} (0={sum(y==0):,}, 1={sum(y==1):,})")

# ── 4. 모델 A: Statsmodels 다변량 로지스틱 회귀 ──────────
print("\n" + "─" * 40)
print("모델 A: 다변량 로지스틱 회귀 (Statsmodels)")
print("─" * 40)

X_sm   = sm.add_constant(X_scaled.astype(float))
model  = sm.Logit(y, X_sm)
result = model.fit(method='bfgs', maxiter=300, disp=False)
print(result.summary2())

# OR 및 95% CI 추출
params  = result.params
conf    = result.conf_int()
pvalues = result.pvalues

logit_results = pd.DataFrame({
    'Variable'  : params.index,
    'coef'      : params.values,
    'OR'        : np.exp(params.values),
    'CI_lower'  : np.exp(conf[0].values),
    'CI_upper'  : np.exp(conf[1].values),
    'p_value'   : pvalues.values,
    'Significant': pvalues.values < 0.05,
}).query("Variable != 'const'").reset_index(drop=True)

logit_results['OR_CI'] = logit_results.apply(
    lambda r: f"{r['OR']:.2f} ({r['CI_lower']:.2f}–{r['CI_upper']:.2f})", axis=1)
logit_results['p_fmt'] = logit_results['p_value'].apply(
    lambda p: '<0.001' if p < 0.001 else f'{p:.3f}')

print("\n[Adjusted Odds Ratios — 다변량 분석]")
print(logit_results[['Variable','OR_CI','p_fmt','Significant']].to_string(index=False))

# ── 5. 모델 적합도 검정 (Hosmer-Lemeshow) ─────────────────
def hosmer_lemeshow_test(y_true, y_pred, g=10):
    """
    Hosmer-Lemeshow goodness-of-fit test
    H0: 모델이 데이터에 잘 적합함 (p > 0.05 → 양호)
    """
    df_hl = pd.DataFrame({'obs': y_true, 'pred': y_pred})
    df_hl['decile'] = pd.qcut(y_pred, g, labels=False, duplicates='drop')
    grouped = df_hl.groupby('decile').agg(
        obs_1   = ('obs', 'sum'),
        pred_1  = ('pred', 'sum'),
        n       = ('obs', 'count'),
        pred_0  = ('pred', lambda x: (1-x).sum()),
        obs_0   = ('obs', lambda x: (1-x).sum()),
    ).reset_index()
    hl_stat = (
        ((grouped['obs_1'] - grouped['pred_1'])**2 / grouped['pred_1']).sum() +
        ((grouped['obs_0'] - grouped['pred_0'])**2 / grouped['pred_0']).sum()
    )
    p_val = 1 - stats.chi2.cdf(hl_stat, df=g-2)
    return hl_stat, p_val

y_pred_prob = result.predict(X_sm)
hl_stat, hl_p = hosmer_lemeshow_test(y.values, y_pred_prob.values)
print(f"\nHosmer-Lemeshow 검정: χ²={hl_stat:.3f}, p={hl_p:.3f}")
print(f"  → {'적합 양호 (H0 기각 불가)' if hl_p > 0.05 else '적합 불량 (H0 기각)'}")

# Nagelkerke R²
ll_full  = result.llf
ll_null  = result.llnull
n_obs    = len(y)
cox_snell = 1 - np.exp(2/n_obs * (ll_null - ll_full))
nag_r2    = cox_snell / (1 - np.exp(2/n_obs * ll_null))
print(f"Nagelkerke R² = {nag_r2:.3f}")
print(f"AUC (train)   = {roc_auc_score(y, y_pred_prob):.3f}")

# ── 6. 모델 B: LASSO 정규화 로지스틱 회귀 ────────────────
print("\n" + "─" * 40)
print("모델 B: LASSO 정규화 로지스틱 회귀 (변수 선택)")
print("─" * 40)

cv_folds = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)

# 최적 C (= 1/lambda) 탐색
lasso_cv = LogisticRegressionCV(
    Cs=np.logspace(-4, 2, 50),
    cv=cv_folds,
    penalty='l1',
    solver='liblinear',
    scoring='roc_auc',
    random_state=SEED,
    max_iter=1000,
    n_jobs=-1
)
lasso_cv.fit(X_scaled, y)

best_C   = lasso_cv.C_[0]
best_auc = cross_val_score(
    LogisticRegression(penalty='l1', C=best_C, solver='liblinear',
                       random_state=SEED, max_iter=1000),
    X_scaled, y, cv=cv_folds, scoring='roc_auc'
).mean()

print(f"최적 C (1/λ) = {best_C:.4f} (λ = {1/best_C:.4f})")
print(f"LASSO CV AUROC = {best_auc:.3f}")

# LASSO 계수
lasso_model = LogisticRegression(
    penalty='l1', C=best_C, solver='liblinear',
    random_state=SEED, max_iter=1000
)
lasso_model.fit(X_scaled, y)

lasso_coef = pd.DataFrame({
    'Variable'  : ALL_PREDICTORS,
    'Coef_LASSO': lasso_model.coef_[0],
    'OR_LASSO'  : np.exp(lasso_model.coef_[0]),
    'Selected'  : lasso_model.coef_[0] != 0
}).sort_values('Coef_LASSO', key=abs, ascending=False)

selected_vars = lasso_coef[lasso_coef['Selected']]['Variable'].tolist()
print(f"\nLASSO 선택 변수 ({len(selected_vars)}개):")
print(lasso_coef[lasso_coef['Selected']][
    ['Variable','Coef_LASSO','OR_LASSO']].to_string(index=False))
print(f"\n제거된 변수 ({sum(~lasso_coef['Selected'])}개):")
print(lasso_coef[~lasso_coef['Selected']]['Variable'].tolist())

# ── 7. Figure 8: aOR Forest Plot (Pub-ready) ─────────────
print("\n[Figure 8] 다변량 aOR Forest Plot 생성 중...")

# 유의한 변수 + LASSO 선택 변수 union으로 플롯
plot_vars  = logit_results[logit_results['Variable'].isin(
    set(logit_results[logit_results['Significant']]['Variable']) |
    set(selected_vars))].copy()
plot_vars  = plot_vars.sort_values('OR')

fig8, ax8  = plt.subplots(figsize=(10, max(6, len(plot_vars)*0.55 + 2)))

y_pos      = np.arange(len(plot_vars))
bar_colors = [COLORS['positive'] if sig else COLORS['ns']
              for sig in plot_vars['Significant']]

ax8.scatter(plot_vars['OR'], y_pos, color=bar_colors,
            s=60, zorder=4)
ax8.hlines(y_pos,
           plot_vars['CI_lower'], plot_vars['CI_upper'],
           color=bar_colors, linewidth=1.8, alpha=0.8)

# LASSO 선택 표시
for i, (_, row) in enumerate(plot_vars.iterrows()):
    if row['Variable'] in selected_vars:
        ax8.annotate('★', xy=(row['CI_upper'], i),
                     xytext=(3, 0), textcoords='offset points',
                     fontsize=9, color=COLORS['lasso'], va='center')

ax8.axvline(1.0, color='black', lw=1.2, ls='--', alpha=0.7)
ax8.set_yticks(y_pos)
ax8.set_yticklabels(plot_vars['Variable'], fontsize=9)
ax8.set_xlabel('Adjusted Odds Ratio (95% CI)', fontsize=10)
ax8.set_title(
    'Figure 8. Adjusted Odds Ratios from Multivariable Logistic Regression\n'
    '(★ = also selected by LASSO)',
    fontsize=11, fontweight='bold'
)

# OR 값 우측 표시
x_max = plot_vars['CI_upper'].max()
for i, (_, row) in enumerate(plot_vars.iterrows()):
    ax8.text(x_max * 1.02, i, row['OR_CI'],
             va='center', fontsize=7.5)
ax8.set_xlim(right=x_max * 1.45)

legend_handles = [
    Patch(facecolor=COLORS['positive'], alpha=0.8, label='Significant (p<0.05)'),
    Patch(facecolor=COLORS['ns'],       alpha=0.8, label='Non-significant'),
]
ax8.legend(handles=legend_handles, fontsize=8, frameon=False, loc='lower right')
plt.tight_layout()
plt.savefig('fig8_aOR_forest_plot.png', dpi=300, bbox_inches='tight')
plt.show()
print("  → fig8_aOR_forest_plot.png 저장 완료")

# ── 8. Figure 9: LASSO 계수 경로 시각화 ──────────────────
print("[Figure 9] LASSO 계수 경로 시각화 중...")

Cs    = np.logspace(-4, 2, 60)
coefs = []
for c in Cs:
    m = LogisticRegression(penalty='l1', C=c, solver='liblinear',
                           max_iter=500, random_state=SEED)
    m.fit(X_scaled, y)
    coefs.append(m.coef_[0])
coefs = np.array(coefs)

fig9, ax9 = plt.subplots(figsize=(12, 6))
cmap9 = plt.cm.get_cmap('tab20', len(ALL_PREDICTORS))
for j, var in enumerate(ALL_PREDICTORS):
    ax9.plot(np.log10(Cs), coefs[:, j], lw=1.0,
             color=cmap9(j), alpha=0.8)
    # 종점 레이블 (0이 아닌 변수만)
    if coefs[-1, j] != 0:
        ax9.text(np.log10(Cs[-1]) + 0.05, coefs[-1, j],
                 var, fontsize=6.5, va='center')

ax9.axvline(np.log10(best_C), color='red', ls='--', lw=1.5,
            label=f'Optimal C={best_C:.4f}')
ax9.axhline(0, color='black', lw=0.5, alpha=0.5)
ax9.set_xlabel('log₁₀(C)  [C = 1/λ, larger = less regularization]',
               fontsize=10)
ax9.set_ylabel('Coefficient', fontsize=10)
ax9.set_title('Figure 9. LASSO Regularization Path\n'
              '(Variables shrink to zero as regularization increases)',
              fontsize=11, fontweight='bold')
ax9.legend(fontsize=9, frameon=False)
plt.tight_layout()
plt.savefig('fig9_lasso_path.png', dpi=300, bbox_inches='tight')
plt.show()
print("  → fig9_lasso_path.png 저장 완료")

# ── 9. Publication-ready Table 3 ─────────────────────────
print("\n" + "─" * 60)
print("TABLE 3: Multivariable Logistic Regression Results")
print("─" * 60)

table3 = logit_results[['Variable','OR_CI','p_fmt','Significant']].copy()
table3.columns = ['Variable','aOR (95% CI)','p-value','Significant']
table3['LASSO Selected'] = table3['Variable'].isin(selected_vars)
table3 = table3.sort_values('Significant', ascending=False)

print(table3.to_string(index=False))
print(f"\nModel fit: Nagelkerke R²={nag_r2:.3f}, "
      f"HL p={hl_p:.3f}, AUROC={roc_auc_score(y, y_pred_prob):.3f}")
print(f"LASSO CV AUROC (5-fold)={best_auc:.3f}")

print("\n" + "=" * 60)
print("다변량 분석 완료")
print(f"저장된 Figure: fig8_aOR_forest_plot.png, fig9_lasso_path.png")
print("=" * 60)
