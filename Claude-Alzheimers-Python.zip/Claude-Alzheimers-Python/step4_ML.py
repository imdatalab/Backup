# ============================================================
# STEP 4: Machine Learning Prediction Models — TRIPOD
# Dataset: Alzheimer's Disease Dataset (n=2,149)
# Models:  Random Forest, XGBoost, LightGBM, Stacking
# Eval:    AUROC, sensitivity, specificity, PPV, NPV
#          5-fold stratified CV + SHAP explainability
# Standards: TRIPOD guideline (transparent reporting)
# ============================================================

# ── 0. 라이브러리 설치 및 임포트 ──────────────────────────
# !pip install xgboost lightgbm shap imbalanced-learn --quiet

import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import Patch
import seaborn as sns
from scipy import stats

# Sklearn
from sklearn.model_selection    import (StratifiedKFold, cross_val_score,
                                         train_test_split)
from sklearn.preprocessing      import StandardScaler, label_binarize
from sklearn.linear_model       import LogisticRegression
from sklearn.ensemble           import RandomForestClassifier, StackingClassifier
from sklearn.metrics            import (roc_auc_score, roc_curve, auc,
                                         confusion_matrix,
                                         precision_recall_curve,
                                         average_precision_score,
                                         classification_report,
                                         brier_score_loss,
                                         ConfusionMatrixDisplay)
from sklearn.calibration        import calibration_curve, CalibratedClassifierCV
from sklearn.pipeline           import Pipeline

# Imbalanced learning
try:
    from imblearn.over_sampling  import SMOTE
    from imblearn.pipeline       import Pipeline as ImbPipeline
    HAS_IMBLEARN = True
except ImportError:
    HAS_IMBLEARN = False
    print("[WARNING] imbalanced-learn 미설치 → SMOTE 생략")

# XGBoost / LightGBM
try:
    from xgboost  import XGBClassifier
    HAS_XGB = True
except ImportError:
    HAS_XGB = False
    print("[WARNING] XGBoost 미설치 → 대체 모델 사용")

try:
    import lightgbm as lgb
    HAS_LGB = True
except ImportError:
    HAS_LGB = False
    print("[WARNING] LightGBM 미설치")

# SHAP
try:
    import shap
    HAS_SHAP = True
except ImportError:
    HAS_SHAP = False
    print("[WARNING] SHAP 미설치 → Feature importance로 대체")

SEED = 42
np.random.seed(SEED)

COLORS = {
    'primary'  : '#0072B2',
    'positive' : '#D55E00',
    'negative' : '#009E73',
    'neutral'  : '#E69F00',
    'highlight': '#CC79A7',
    'ns'       : '#999999',
}

plt.rcParams.update({
    'font.family'      : 'DejaVu Sans',
    'font.size'        : 10,
    'axes.spines.top'  : False,
    'axes.spines.right': False,
    'figure.dpi'       : 150,
    'savefig.dpi'      : 300,
    'savefig.bbox'     : 'tight',
    'savefig.facecolor': 'white',
})

# ── 1. 데이터 로드 ─────────────────────────────────────────
print("=" * 60)
print("STEP 4: MACHINE LEARNING PREDICTION MODELS (TRIPOD)")
print("=" * 60)

try:
    df = pd.read_csv('alzheimers.csv')
    print(f"[OK] 데이터 로드: {df.shape}")
except FileNotFoundError:
    print("[INFO] 시뮬레이션 데이터 사용")
    np.random.seed(SEED)
    n = 2149
    diag = np.random.choice([0,1], n, p=[0.647,0.353])
    df = pd.DataFrame({
        'Age': np.where(diag==1, np.random.normal(78,8,n),
                        np.random.normal(73,9,n)).clip(60,90).astype(int),
        'Gender': np.random.randint(0,2,n),
        'Ethnicity': np.random.choice([0,1,2,3],n),
        'EducationLevel': np.random.choice([0,1,2,3],n),
        'BMI': np.random.uniform(15,40,n),
        'Smoking': np.random.randint(0,2,n),
        'AlcoholConsumption': np.random.uniform(0,20,n),
        'PhysicalActivity': np.random.uniform(0,10,n),
        'DietQuality': np.random.uniform(0,10,n),
        'SleepQuality': np.random.uniform(4,10,n),
        'FamilyHistoryAlzheimers': np.random.randint(0,2,n),
        'CardiovascularDisease': np.random.randint(0,2,n),
        'Diabetes': np.random.randint(0,2,n),
        'Depression': np.random.randint(0,2,n),
        'HeadInjury': np.random.randint(0,2,n),
        'Hypertension': np.random.randint(0,2,n),
        'SystolicBP': np.random.randint(90,180,n),
        'DiastolicBP': np.random.randint(60,120,n),
        'CholesterolTotal': np.random.uniform(150,300,n),
        'CholesterolLDL': np.random.uniform(50,200,n),
        'CholesterolHDL': np.random.uniform(20,100,n),
        'CholesterolTriglycerides': np.random.uniform(50,400,n),
        'MMSE': np.where(diag==1,
                         np.random.normal(10,6,n).clip(0,30),
                         np.random.normal(20,5,n).clip(0,30)),
        'FunctionalAssessment': np.where(diag==1,
                         np.random.normal(3.5,2,n).clip(0,10),
                         np.random.normal(6.5,2,n).clip(0,10)),
        'MemoryComplaints': np.where(diag==1,
                         np.random.binomial(1,0.6,n),
                         np.random.binomial(1,0.15,n)),
        'BehavioralProblems': np.random.randint(0,2,n),
        'ADL': np.where(diag==1,
                         np.random.normal(3,2,n).clip(0,10),
                         np.random.normal(7,2,n).clip(0,10)),
        'Confusion': np.random.randint(0,2,n),
        'Disorientation': np.random.randint(0,2,n),
        'PersonalityChanges': np.random.randint(0,2,n),
        'DifficultyCompletingTasks': np.random.randint(0,2,n),
        'Forgetfulness': np.random.randint(0,2,n),
        'Diagnosis': diag,
    })

DROP = ['PatientID', 'DoctorInCharge']
df   = df.drop(columns=DROP, errors='ignore')
TARGET = 'Diagnosis'
FEATURES = [c for c in df.columns if c != TARGET]

X = df[FEATURES].values
y = df[TARGET].values

print(f"특징 변수: {len(FEATURES)}개 | 샘플: {len(y):,} "
      f"| 양성(AD): {sum(y==1):,} ({sum(y==1)/len(y)*100:.1f}%)")

# ── 2. Train/Test Split (80:20, stratified) ───────────────
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=SEED
)
print(f"\nTrain: {len(y_train):,} | Test: {len(y_test):,}")
print(f"  Train AD: {sum(y_train==1)} ({sum(y_train==1)/len(y_train)*100:.1f}%)")
print(f"  Test  AD: {sum(y_test==1)}  ({sum(y_test==1)/len(y_test)*100:.1f}%)")

# 스케일러
scaler  = StandardScaler()
X_train_sc = scaler.fit_transform(X_train)
X_test_sc  = scaler.transform(X_test)

# ── 3. 모델 정의 ───────────────────────────────────────────
models = {}

# (1) Logistic Regression (baseline)
models['LR'] = LogisticRegression(
    C=1.0, max_iter=1000, random_state=SEED, class_weight='balanced'
)

# (2) Random Forest
models['RF'] = RandomForestClassifier(
    n_estimators=300, max_depth=8, min_samples_leaf=5,
    class_weight='balanced', n_jobs=-1, random_state=SEED
)

# (3) XGBoost
if HAS_XGB:
    scale_pos = sum(y_train==0) / sum(y_train==1)
    models['XGB'] = XGBClassifier(
        n_estimators=300, max_depth=5, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8,
        scale_pos_weight=scale_pos,
        eval_metric='auc', use_label_encoder=False,
        random_state=SEED, verbosity=0
    )

# (4) LightGBM
if HAS_LGB:
    models['LGB'] = lgb.LGBMClassifier(
        n_estimators=300, max_depth=5, learning_rate=0.05,
        num_leaves=31, subsample=0.8, colsample_bytree=0.8,
        class_weight='balanced', random_state=SEED,
        verbose=-1
    )

# (5) Stacking ensemble
if HAS_XGB and HAS_LGB:
    base_estimators = [
        ('rf',  RandomForestClassifier(n_estimators=200, random_state=SEED,
                                        class_weight='balanced', n_jobs=-1)),
        ('xgb', XGBClassifier(n_estimators=200, scale_pos_weight=scale_pos,
                               random_state=SEED, verbosity=0,
                               use_label_encoder=False, eval_metric='auc')),
        ('lgb', lgb.LGBMClassifier(n_estimators=200, class_weight='balanced',
                                    random_state=SEED, verbose=-1)),
    ]
    models['Stack'] = StackingClassifier(
        estimators=base_estimators,
        final_estimator=LogisticRegression(C=1.0, max_iter=500,
                                           random_state=SEED),
        cv=5, n_jobs=-1, passthrough=False
    )

print(f"\n학습 모델 목록: {list(models.keys())}")

# ── 4. 5-fold Stratified CV 평가 ──────────────────────────
print("\n" + "─" * 40)
print("5-Fold Stratified Cross-Validation")
print("─" * 40)

cv_folds = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
cv_results = {}

for name, model in models.items():
    print(f"  [{name}] 학습 중...", end=' ')
    auc_scores = cross_val_score(
        model, X_train_sc, y_train, cv=cv_folds,
        scoring='roc_auc', n_jobs=-1
    )
    cv_results[name] = {
        'AUC_mean': auc_scores.mean(),
        'AUC_std' : auc_scores.std(),
        'AUC_all' : auc_scores
    }
    print(f"AUROC = {auc_scores.mean():.3f} ± {auc_scores.std():.3f}")

# ── 5. 최종 모델 학습 및 Test set 평가 ───────────────────
print("\n" + "─" * 40)
print("Test Set 최종 평가")
print("─" * 40)

def evaluate_model(model, X_tr, y_tr, X_te, y_te, threshold=0.5):
    """
    모델 학습 후 test set에서 전체 성능 지표 반환
    Returns: dict with all metrics
    """
    model.fit(X_tr, y_tr)
    y_prob = model.predict_proba(X_te)[:, 1]
    y_pred = (y_prob >= threshold).astype(int)

    tn, fp, fn, tp = confusion_matrix(y_te, y_pred).ravel()
    sensitivity  = tp / (tp + fn)
    specificity  = tn / (tn + fp)
    ppv          = tp / (tp + fp) if (tp + fp) > 0 else 0
    npv          = tn / (tn + fn) if (tn + fn) > 0 else 0
    f1           = 2 * ppv * sensitivity / (ppv + sensitivity) if (ppv + sensitivity) > 0 else 0
    auroc        = roc_auc_score(y_te, y_prob)
    brier        = brier_score_loss(y_te, y_prob)
    avg_prec     = average_precision_score(y_te, y_prob)

    return {
        'model'       : model,
        'y_prob'      : y_prob,
        'AUROC'       : auroc,
        'Sensitivity' : sensitivity,
        'Specificity' : specificity,
        'PPV'         : ppv,
        'NPV'         : npv,
        'F1'          : f1,
        'Brier'       : brier,
        'AUPRC'       : avg_prec,
        'TP': tp, 'TN': tn, 'FP': fp, 'FN': fn,
    }

test_results = {}
for name, model in models.items():
    print(f"  [{name}]", end=' ')
    result = evaluate_model(model, X_train_sc, y_train,
                             X_test_sc, y_test)
    test_results[name] = result
    print(f"AUROC={result['AUROC']:.3f}  "
          f"Sens={result['Sensitivity']:.3f}  "
          f"Spec={result['Specificity']:.3f}  "
          f"Brier={result['Brier']:.3f}")

# ── 6. Figure 10: ROC Curves ──────────────────────────────
print("\n[Figure 10] ROC Curve 생성 중...")

model_colors = {
    'LR'   : COLORS['ns'],
    'RF'   : COLORS['primary'],
    'XGB'  : COLORS['positive'],
    'LGB'  : COLORS['neutral'],
    'Stack': COLORS['highlight'],
}

fig10, ax10 = plt.subplots(figsize=(8, 7))
ax10.plot([0,1],[0,1], 'k--', lw=0.8, alpha=0.5, label='Random (AUC=0.500)')

for name, res in test_results.items():
    fpr, tpr, _ = roc_curve(y_test, res['y_prob'])
    lw = 2.5 if name == 'Stack' else 1.8
    ax10.plot(fpr, tpr, lw=lw,
              color=model_colors.get(name, 'gray'),
              label=f"{name}  (AUC={res['AUROC']:.3f})")

ax10.set_xlabel('1 – Specificity (False Positive Rate)', fontsize=11)
ax10.set_ylabel('Sensitivity (True Positive Rate)', fontsize=11)
ax10.set_title('Figure 10. ROC Curves — Alzheimer\'s Prediction Models\n'
               '(Test set, n=%d)' % len(y_test),
               fontsize=12, fontweight='bold')
ax10.legend(fontsize=9, frameon=True, framealpha=0.9, loc='lower right')
ax10.set_xlim(-0.01, 1.01)
ax10.set_ylim(-0.01, 1.01)
plt.tight_layout()
plt.savefig('fig10_roc_curves.png', dpi=300, bbox_inches='tight')
plt.show()
print("  → fig10_roc_curves.png 저장 완료")

# ── 7. Figure 11: Performance Comparison ─────────────────
print("[Figure 11] 모델 성능 비교 차트 생성 중...")

metrics_for_plot = ['AUROC','Sensitivity','Specificity','PPV','NPV','F1']
perf_data = {name: [res[m] for m in metrics_for_plot]
             for name, res in test_results.items()}
perf_df = pd.DataFrame(perf_data, index=metrics_for_plot)

fig11, ax11 = plt.subplots(figsize=(11, 6))
x     = np.arange(len(metrics_for_plot))
n_m   = len(test_results)
width = 0.8 / n_m

for i, (name, vals) in enumerate(perf_data.items()):
    offset = (i - n_m/2 + 0.5) * width
    bars   = ax11.bar(x + offset, vals, width*0.9,
                      color=model_colors.get(name, 'gray'),
                      alpha=0.8, label=name, edgecolor='white')
    for bar, val in zip(bars, vals):
        ax11.text(bar.get_x() + bar.get_width()/2,
                  bar.get_height() + 0.004,
                  f'{val:.3f}', ha='center', va='bottom',
                  fontsize=6.5, rotation=90)

ax11.set_xticks(x)
ax11.set_xticklabels(metrics_for_plot, fontsize=10)
ax11.set_ylim(0, 1.12)
ax11.set_ylabel('Score', fontsize=10)
ax11.set_title('Figure 11. Model Performance Comparison\n'
               '(Test set evaluation)',
               fontsize=12, fontweight='bold')
ax11.legend(fontsize=8.5, frameon=False, ncol=n_m)
ax11.axhline(0.8, color='red', ls=':', lw=1.0, alpha=0.5,
             label='Reference 0.8')
plt.tight_layout()
plt.savefig('fig11_model_comparison.png', dpi=300, bbox_inches='tight')
plt.show()
print("  → fig11_model_comparison.png 저장 완료")

# ── 8. Figure 12: Confusion Matrix (Best model) ───────────
print("[Figure 12] Confusion Matrix 생성 중...")

best_model_name = max(test_results, key=lambda k: test_results[k]['AUROC'])
best_res        = test_results[best_model_name]
y_pred_best     = (best_res['y_prob'] >= 0.5).astype(int)

fig12, ax12 = plt.subplots(figsize=(6, 5))
cm = confusion_matrix(y_test, y_pred_best)
cmd = ConfusionMatrixDisplay(confusion_matrix=cm,
                              display_labels=['No AD', 'Alzheimer\'s'])
cmd.plot(ax=ax12, colorbar=False, cmap='Blues')
ax12.set_title(
    f'Figure 12. Confusion Matrix — {best_model_name}\n'
    f'(AUROC={best_res["AUROC"]:.3f}, threshold=0.5)',
    fontsize=11, fontweight='bold'
)
plt.tight_layout()
plt.savefig('fig12_confusion_matrix.png', dpi=300, bbox_inches='tight')
plt.show()
print("  → fig12_confusion_matrix.png 저장 완료")

# ── 9. Figure 13: SHAP Summary Plot ──────────────────────
if HAS_SHAP and 'RF' in test_results:
    print("[Figure 13] SHAP Beeswarm Plot 생성 중...")
    best_fitted = test_results[best_model_name]['model']

    try:
        # Tree-based SHAP explainer
        explainer = shap.TreeExplainer(best_fitted)
        shap_vals  = explainer.shap_values(X_test_sc)

        # 이진 분류: shap_values[1] = 양성 클래스
        sv = shap_vals[1] if isinstance(shap_vals, list) else shap_vals

        fig13, ax13 = plt.subplots(figsize=(10, 8))
        shap.summary_plot(
            sv, X_test_sc,
            feature_names=FEATURES,
            plot_type='dot',
            max_display=20,
            show=False,
            color_bar_label='Feature value'
        )
        plt.title(f'Figure 13. SHAP Beeswarm Plot — {best_model_name}\n'
                  f'(Top 20 Features, n_test={len(y_test)})',
                  fontsize=12, fontweight='bold')
        plt.tight_layout()
        plt.savefig('fig13_shap_beeswarm.png', dpi=300, bbox_inches='tight')
        plt.show()
        print("  → fig13_shap_beeswarm.png 저장 완료")
    except Exception as e:
        print(f"  [SHAP 오류] {e} → Feature Importance로 대체")
        HAS_SHAP = False

if not HAS_SHAP and 'RF' in test_results:
    print("[Figure 13] Feature Importance (RF) 생성 중...")
    rf_model = test_results['RF']['model']
    importance_df = pd.DataFrame({
        'Feature'   : FEATURES,
        'Importance': rf_model.feature_importances_
    }).sort_values('Importance', ascending=True).tail(20)

    fig13, ax13 = plt.subplots(figsize=(9, 8))
    colors_fi = [COLORS['positive'] if imp > importance_df['Importance'].median()
                 else COLORS['primary'] for imp in importance_df['Importance']]
    ax13.barh(importance_df['Feature'], importance_df['Importance'],
              color=colors_fi, edgecolor='none', height=0.65)
    ax13.set_xlabel('Mean Decrease in Impurity', fontsize=10)
    ax13.set_title('Figure 13. Random Forest Feature Importance\n'
                   '(Top 20 Variables)',
                   fontsize=12, fontweight='bold')
    plt.tight_layout()
    plt.savefig('fig13_feature_importance.png', dpi=300, bbox_inches='tight')
    plt.show()
    print("  → fig13_feature_importance.png 저장 완료")

# ── 10. Publication Table 4 ───────────────────────────────
print("\n" + "─" * 60)
print("TABLE 4: Model Performance Summary (Test Set)")
print("─" * 60)

perf_rows = []
for name, res in test_results.items():
    cv_auc = cv_results[name]
    perf_rows.append({
        'Model'       : name,
        'CV AUROC'    : f"{cv_auc['AUC_mean']:.3f}±{cv_auc['AUC_std']:.3f}",
        'Test AUROC'  : f"{res['AUROC']:.3f}",
        'Sensitivity' : f"{res['Sensitivity']:.3f}",
        'Specificity' : f"{res['Specificity']:.3f}",
        'PPV'         : f"{res['PPV']:.3f}",
        'NPV'         : f"{res['NPV']:.3f}",
        'F1'          : f"{res['F1']:.3f}",
        'Brier Score' : f"{res['Brier']:.3f}",
        'AUPRC'       : f"{res['AUPRC']:.3f}",
    })

table4 = pd.DataFrame(perf_rows)
print(table4.to_string(index=False))
print(f"\n★ Best model: {best_model_name} (AUROC={best_res['AUROC']:.3f})")

# 95% CI for AUROC (DeLong method approximation)
def auc_ci_delong(y_true, y_score, alpha=0.05):
    """Bootstrap 95% CI for AUROC"""
    n_boot = 1000
    boot_aucs = []
    for _ in range(n_boot):
        idx = np.random.choice(len(y_true), len(y_true), replace=True)
        if len(np.unique(y_true[idx])) < 2:
            continue
        boot_aucs.append(roc_auc_score(y_true[idx], y_score[idx]))
    ci_lo = np.percentile(boot_aucs, alpha/2*100)
    ci_hi = np.percentile(boot_aucs, (1-alpha/2)*100)
    return ci_lo, ci_hi

print(f"\n[{best_model_name}] AUROC Bootstrap 95% CI 계산 중...")
ci_lo, ci_hi = auc_ci_delong(y_test, best_res['y_prob'])
print(f"  AUROC = {best_res['AUROC']:.3f} (95% CI: {ci_lo:.3f}–{ci_hi:.3f})")

print("\n" + "=" * 60)
print("ML 예측 모델 완료")
print("저장된 Figure: fig10~fig13")
print("=" * 60)
