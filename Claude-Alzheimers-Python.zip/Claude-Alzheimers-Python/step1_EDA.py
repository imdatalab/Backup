# ============================================================
# STEP 1: Exploratory Data Analysis (EDA)
# Dataset: Alzheimer's Disease Dataset (n=2,149)
# Purpose: Data quality assessment, distribution analysis,
#          class imbalance check, correlation structure
# Requirements: pandas, numpy, matplotlib, seaborn, scipy
# Output: 300 DPI publication-ready figures
# ============================================================

# ── 0. 라이브러리 설치 (Google Colab) ──────────────────────
# !pip install pandas numpy matplotlib seaborn scipy --quiet

import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patches as mpatches
from matplotlib.ticker import MaxNLocator
import seaborn as sns
from scipy import stats
from scipy.stats import shapiro, normaltest
import os

# ── 재현성 시드 ────────────────────────────────────────────
SEED = 42
np.random.seed(SEED)

# ── 출판용 색상 팔레트 (colorblind-friendly) ───────────────
COLORS = {
    'primary'  : '#0072B2',   # blue
    'secondary': '#E69F00',   # amber
    'positive' : '#D55E00',   # vermillion  (Diagnosis=1)
    'negative' : '#0072B2',   # blue        (Diagnosis=0)
    'neutral'  : '#009E73',   # green
    'highlight': '#CC79A7',   # pink
    'gray'     : '#999999',
}
PALETTE = [COLORS['negative'], COLORS['positive']]

# matplotlib 전역 설정
plt.rcParams.update({
    'font.family'      : 'DejaVu Sans',
    'font.size'        : 10,
    'axes.titlesize'   : 11,
    'axes.labelsize'   : 10,
    'axes.spines.top'  : False,
    'axes.spines.right': False,
    'figure.dpi'       : 150,
    'savefig.dpi'      : 300,
    'savefig.bbox'     : 'tight',
    'savefig.facecolor': 'white',
})

# ── 1. 데이터 로드 ─────────────────────────────────────────
print("=" * 60)
print("STEP 1: EXPLORATORY DATA ANALYSIS")
print("=" * 60)

try:
    # Colab에서 파일 업로드 시:
    # from google.colab import files
    # uploaded = files.upload()
    # df = pd.read_csv(list(uploaded.keys())[0])

    df = pd.read_csv('alzheimers.csv')   # ← 파일명 수정
    print(f"[OK] 데이터 로드 완료: {df.shape[0]:,}행 × {df.shape[1]}열")
except FileNotFoundError:
    # 로컬 테스트용: 데이터 시뮬레이션
    print("[INFO] 파일 미발견 → 시뮬레이션 데이터 생성")
    np.random.seed(SEED)
    n = 2149
    diag = np.random.choice([0,1], n, p=[0.647,0.353])
    df = pd.DataFrame({
        'PatientID': range(4751, 4751+n),
        'Age': np.random.randint(60, 91, n),
        'Gender': np.random.randint(0, 2, n),
        'Ethnicity': np.random.choice([0,1,2,3], n),
        'EducationLevel': np.random.choice([0,1,2,3], n),
        'BMI': np.random.uniform(15, 40, n),
        'Smoking': np.random.randint(0, 2, n),
        'AlcoholConsumption': np.random.uniform(0, 20, n),
        'PhysicalActivity': np.random.uniform(0, 10, n),
        'DietQuality': np.random.uniform(0, 10, n),
        'SleepQuality': np.random.uniform(4, 10, n),
        'FamilyHistoryAlzheimers': np.random.randint(0, 2, n),
        'CardiovascularDisease': np.random.randint(0, 2, n),
        'Diabetes': np.random.randint(0, 2, n),
        'Depression': np.random.randint(0, 2, n),
        'HeadInjury': np.random.randint(0, 2, n),
        'Hypertension': np.random.randint(0, 2, n),
        'SystolicBP': np.random.randint(90, 180, n),
        'DiastolicBP': np.random.randint(60, 120, n),
        'CholesterolTotal': np.random.uniform(150, 300, n),
        'CholesterolLDL': np.random.uniform(50, 200, n),
        'CholesterolHDL': np.random.uniform(20, 100, n),
        'CholesterolTriglycerides': np.random.uniform(50, 400, n),
        'MMSE': np.where(diag==1,
                         np.random.normal(10, 6, n).clip(0,30),
                         np.random.normal(20, 5, n).clip(0,30)),
        'FunctionalAssessment': np.random.uniform(0, 10, n),
        'MemoryComplaints': np.random.randint(0, 2, n),
        'BehavioralProblems': np.random.randint(0, 2, n),
        'ADL': np.random.uniform(0, 10, n),
        'Confusion': np.random.randint(0, 2, n),
        'Disorientation': np.random.randint(0, 2, n),
        'PersonalityChanges': np.random.randint(0, 2, n),
        'DifficultyCompletingTasks': np.random.randint(0, 2, n),
        'Forgetfulness': np.random.randint(0, 2, n),
        'Diagnosis': diag,
        'DoctorInCharge': 'XXXConfid'
    })

# ── 2. 변수 분류 ───────────────────────────────────────────
DROP_COLS = ['PatientID', 'DoctorInCharge']
df_clean = df.drop(columns=DROP_COLS, errors='ignore')

CONTINUOUS_VARS = [
    'Age', 'BMI', 'AlcoholConsumption', 'PhysicalActivity',
    'DietQuality', 'SleepQuality', 'SystolicBP', 'DiastolicBP',
    'CholesterolTotal', 'CholesterolLDL', 'CholesterolHDL',
    'CholesterolTriglycerides', 'MMSE', 'FunctionalAssessment', 'ADL'
]
BINARY_VARS = [
    'Gender', 'Smoking', 'FamilyHistoryAlzheimers', 'CardiovascularDisease',
    'Diabetes', 'Depression', 'HeadInjury', 'Hypertension',
    'MemoryComplaints', 'BehavioralProblems', 'Confusion',
    'Disorientation', 'PersonalityChanges', 'DifficultyCompletingTasks', 'Forgetfulness'
]
ORDINAL_VARS = ['Ethnicity', 'EducationLevel']
TARGET = 'Diagnosis'

print(f"\n변수 구성:")
print(f"  연속형 : {len(CONTINUOUS_VARS)}개")
print(f"  이진형 : {len(BINARY_VARS)}개")
print(f"  순서형 : {len(ORDINAL_VARS)}개")
print(f"  결과변수: {TARGET}")

# ── 3. 데이터 품질 리포트 ──────────────────────────────────
print("\n" + "─" * 40)
print("데이터 품질 평가")
print("─" * 40)

quality_rows = []
for col in df_clean.columns:
    if col == TARGET:
        continue
    miss   = df_clean[col].isna().sum()
    miss_p = miss / len(df_clean) * 100
    if df_clean[col].dtype in [np.float64, np.int64]:
        q1, q3 = df_clean[col].quantile([0.25, 0.75])
        iqr    = q3 - q1
        n_out  = ((df_clean[col] < q1 - 1.5*iqr) |
                  (df_clean[col] > q3 + 1.5*iqr)).sum()
    else:
        n_out = 0
    quality_rows.append({
        'Variable': col,
        'Missing_n': miss,
        'Missing_%': round(miss_p, 1),
        'Outliers_IQR': n_out,
        'Mean/Prop': (round(df_clean[col].mean(), 3)
                      if df_clean[col].dtype == np.float64
                      else round(df_clean[col].mean(), 3)),
        'SD': (round(df_clean[col].std(), 3)
               if df_clean[col].dtype == np.float64 else '-'),
        'Min': df_clean[col].min(),
        'Max': df_clean[col].max(),
    })

quality_df = pd.DataFrame(quality_rows)
print(quality_df.to_string(index=False))
print(f"\n총 결측치: {df_clean.isna().sum().sum()}개 (완전 데이터셋)")

# ── 4. 기술통계 Table 1 ────────────────────────────────────
print("\n" + "─" * 40)
print("기술통계 (Table 1 초안)")
print("─" * 40)

g0 = df_clean[df_clean[TARGET] == 0]
g1 = df_clean[df_clean[TARGET] == 1]

table1_rows = []
for col in CONTINUOUS_VARS:
    row = {'Variable': col, 'Type': 'Continuous'}
    for label, g in [('Overall', df_clean), ('No AD', g0), ('AD', g1)]:
        med  = g[col].median()
        q1   = g[col].quantile(0.25)
        q3   = g[col].quantile(0.75)
        row[label] = f"{med:.1f} [{q1:.1f}–{q3:.1f}]"
    # Normality check
    stat, p_norm = normaltest(df_clean[col].dropna())
    row['Normality_p'] = f"{p_norm:.3f}"
    table1_rows.append(row)

for col in BINARY_VARS + ORDINAL_VARS:
    row = {'Variable': col, 'Type': 'Binary/Ordinal'}
    for label, g in [('Overall', df_clean), ('No AD', g0), ('AD', g1)]:
        n   = (g[col] == 1).sum() if col in BINARY_VARS else len(g)
        pct = n / len(g) * 100
        row[label] = f"{n} ({pct:.1f}%)"
    row['Normality_p'] = 'N/A'
    table1_rows.append(row)

table1 = pd.DataFrame(table1_rows)
print(table1[['Variable', 'Type', 'Overall', 'No AD', 'AD']].to_string(index=False))

# ── 5. Figure 1: 클래스 분포 + 주요 연속형 변수 분포 ───────
print("\n[Figure 1] 클래스 분포 및 주요 변수 분포 생성 중...")

fig = plt.figure(figsize=(18, 14))
gs  = gridspec.GridSpec(3, 5, figure=fig, hspace=0.45, wspace=0.38)

# 1-1. 클래스 분포 (파이차트)
ax_pie = fig.add_subplot(gs[0, 0])
sizes  = [len(g0), len(g1)]
labels = [f'No AD\nn={len(g0):,}\n({len(g0)/len(df_clean)*100:.1f}%)',
          f'Alzheimer\'s\nn={len(g1):,}\n({len(g1)/len(df_clean)*100:.1f}%)']
wedges, texts = ax_pie.pie(
    sizes, labels=labels, colors=PALETTE,
    startangle=90, wedgeprops={'edgecolor': 'white', 'linewidth': 2},
    textprops={'fontsize': 8}
)
ax_pie.set_title('Outcome Distribution', fontweight='bold', pad=10)

# 1-2 ~ 1-15: 연속형 변수 KDE (그룹별)
key_vars = CONTINUOUS_VARS
for idx, var in enumerate(key_vars):
    row_i = (idx + 1) // 5
    col_i = (idx + 1) % 5
    if row_i >= 3:
        break
    ax = fig.add_subplot(gs[row_i, col_i])
    for diag_val, color, label in [(0, COLORS['negative'], 'No AD'),
                                    (1, COLORS['positive'], 'AD')]:
        data = df_clean[df_clean[TARGET] == diag_val][var].dropna()
        ax.hist(data, bins=25, alpha=0.45, color=color, density=True,
                edgecolor='none')
        try:
            from scipy.stats import gaussian_kde
            kde = gaussian_kde(data)
            x_range = np.linspace(data.min(), data.max(), 200)
            ax.plot(x_range, kde(x_range), color=color, lw=1.8, label=label)
        except Exception:
            pass
    ax.set_title(var, fontweight='bold', fontsize=9)
    ax.set_xlabel('')
    ax.yaxis.set_major_locator(MaxNLocator(3))
    if idx == 0:
        ax.legend(fontsize=7, frameon=False, loc='upper right')

# 남은 subplot 숨기기
for i in range(len(key_vars)+1, 15):
    r = i // 5; c = i % 5
    if r < 3:
        fig.add_subplot(gs[r, c]).axis('off')

fig.suptitle(
    "Figure 1. Distribution of Continuous Variables by Diagnosis Group",
    fontsize=13, fontweight='bold', y=1.01
)
plt.savefig('fig1_distributions.png', dpi=300, bbox_inches='tight')
plt.show()
print("  → fig1_distributions.png 저장 완료")

# ── 6. Figure 2: 이진형 변수 prevalence ───────────────────
print("[Figure 2] 이진형 변수 Prevalence 생성 중...")

fig2, axes = plt.subplots(3, 5, figsize=(18, 10))
axes = axes.flatten()

for idx, var in enumerate(BINARY_VARS):
    ax = axes[idx]
    prev = []
    for diag_val, label in [(0, 'No AD'), (1, 'AD')]:
        g = df_clean[df_clean[TARGET] == diag_val]
        prev.append(g[var].mean() * 100)
    bars = ax.bar(['No AD', 'AD'], prev, color=PALETTE,
                  width=0.55, edgecolor='white', linewidth=1.2)
    for bar, val in zip(bars, prev):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.8,
                f'{val:.1f}%', ha='center', va='bottom', fontsize=8,
                fontweight='bold')
    ax.set_title(var.replace('History', 'Hx.').replace('Cardiovascular', 'CVD'),
                 fontsize=9, fontweight='bold')
    ax.set_ylim(0, min(prev[1]*1.5+15, 105))
    ax.set_ylabel('Prevalence (%)', fontsize=8)
    ax.yaxis.set_major_locator(MaxNLocator(4))

for idx in range(len(BINARY_VARS), len(axes)):
    axes[idx].axis('off')

fig2.suptitle(
    "Figure 2. Prevalence of Binary Risk Factors by Diagnosis Group",
    fontsize=13, fontweight='bold'
)
plt.tight_layout()
plt.savefig('fig2_binary_prevalence.png', dpi=300, bbox_inches='tight')
plt.show()
print("  → fig2_binary_prevalence.png 저장 완료")

# ── 7. Figure 3: 상관관계 히트맵 ──────────────────────────
print("[Figure 3] 상관관계 히트맵 생성 중...")

numeric_cols = CONTINUOUS_VARS + ORDINAL_VARS + [TARGET]
corr_matrix  = df_clean[numeric_cols].corr(method='spearman')

mask = np.triu(np.ones_like(corr_matrix, dtype=bool), k=1)

fig3, ax3 = plt.subplots(figsize=(14, 12))
cmap = sns.diverging_palette(220, 20, as_cmap=True)

sns.heatmap(
    corr_matrix, mask=mask, cmap=cmap,
    vmax=0.6, vmin=-0.6, center=0,
    square=True, linewidths=0.3, linecolor='white',
    annot=True, fmt='.2f', annot_kws={'size': 7},
    cbar_kws={'shrink': 0.7, 'label': "Spearman's ρ"},
    ax=ax3
)
ax3.set_title(
    "Figure 3. Spearman Correlation Matrix (Continuous & Ordinal Variables)",
    fontsize=12, fontweight='bold', pad=15
)
ax3.tick_params(axis='x', rotation=45, labelsize=8)
ax3.tick_params(axis='y', rotation=0,  labelsize=8)

plt.tight_layout()
plt.savefig('fig3_correlation_heatmap.png', dpi=300, bbox_inches='tight')
plt.show()
print("  → fig3_correlation_heatmap.png 저장 완료")

# ── 8. Figure 4: MMSE & FunctionalAssessment Boxplot ──────
print("[Figure 4] 주요 임상 지표 Boxplot 생성 중...")

key_clinical = ['MMSE', 'FunctionalAssessment', 'ADL',
                'SleepQuality', 'DietQuality', 'PhysicalActivity']

fig4, axes4 = plt.subplots(2, 3, figsize=(14, 9))
axes4 = axes4.flatten()

for idx, var in enumerate(key_clinical):
    ax = axes4[idx]
    data_plot = [
        df_clean[df_clean[TARGET] == 0][var].dropna().values,
        df_clean[df_clean[TARGET] == 1][var].dropna().values
    ]
    bp = ax.boxplot(
        data_plot, patch_artist=True,
        medianprops={'color': 'black', 'linewidth': 2},
        whiskerprops={'linewidth': 1.2},
        capprops={'linewidth': 1.2},
        flierprops={'marker': 'o', 'markersize': 3,
                    'alpha': 0.4, 'linestyle': 'none'}
    )
    for patch, color in zip(bp['boxes'], PALETTE):
        patch.set_facecolor(color)
        patch.set_alpha(0.7)

    # 개별 데이터 포인트 (jitter)
    for i, (data, color) in enumerate(zip(data_plot, PALETTE)):
        x_jitter = np.random.normal(i+1, 0.06, size=min(len(data), 300))
        sample   = np.random.choice(data, size=min(len(data), 300),
                                    replace=False)
        ax.scatter(x_jitter, sample, alpha=0.2, s=8, color=color,
                   zorder=2)

    ax.set_xticks([1, 2])
    ax.set_xticklabels(['No AD', 'Alzheimer\'s'], fontsize=9)
    ax.set_title(var, fontweight='bold')
    ax.set_ylabel('Score', fontsize=9)

    # Mann-Whitney U p-value
    stat_mw, p_mw = stats.mannwhitneyu(data_plot[0], data_plot[1],
                                        alternative='two-sided')
    ax.text(0.97, 0.97,
            f'p{"<0.001" if p_mw < 0.001 else f"={p_mw:.3f}"}',
            transform=ax.transAxes, ha='right', va='top',
            fontsize=8, style='italic',
            bbox={'boxstyle': 'round,pad=0.2', 'fc': 'lightyellow',
                  'ec': 'gray', 'alpha': 0.8})

fig4.suptitle(
    "Figure 4. Key Clinical Variables by Diagnosis Group (Median [IQR])",
    fontsize=12, fontweight='bold'
)
plt.tight_layout()
plt.savefig('fig4_clinical_boxplot.png', dpi=300, bbox_inches='tight')
plt.show()
print("  → fig4_clinical_boxplot.png 저장 완료")

# ── 9. Figure 5: 이상치 탐지 (IQR method) ─────────────────
print("[Figure 5] 이상치 탐지 요약 생성 중...")

outlier_summary = []
for col in CONTINUOUS_VARS:
    q1, q3 = df_clean[col].quantile([0.25, 0.75])
    iqr    = q3 - q1
    lower  = q1 - 1.5 * iqr
    upper  = q3 + 1.5 * iqr
    n_out  = ((df_clean[col] < lower) | (df_clean[col] > upper)).sum()
    outlier_summary.append({
        'Variable': col,
        'Q1': round(q1, 2), 'Q3': round(q3, 2),
        'IQR Lower': round(lower, 2), 'IQR Upper': round(upper, 2),
        'N Outliers': n_out,
        'Outlier %': round(n_out / len(df_clean) * 100, 2)
    })

outlier_df = pd.DataFrame(outlier_summary).sort_values('N Outliers', ascending=False)

fig5, ax5 = plt.subplots(figsize=(12, 6))
colors_bar = [COLORS['positive'] if x > len(df_clean)*0.05
              else COLORS['primary'] for x in outlier_df['N Outliers']]
bars5 = ax5.barh(outlier_df['Variable'], outlier_df['Outlier %'],
                 color=colors_bar, edgecolor='none', height=0.6)
for bar, val in zip(bars5, outlier_df['Outlier %']):
    ax5.text(val + 0.1, bar.get_y() + bar.get_height()/2,
             f'{val:.1f}%', va='center', fontsize=8)
ax5.axvline(x=5, color='red', linestyle='--', lw=1.2, alpha=0.7,
            label='5% threshold')
ax5.set_xlabel('Outlier Proportion (%)')
ax5.set_title('Figure 5. Outlier Detection by IQR Method',
              fontweight='bold', fontsize=12)
ax5.legend(fontsize=9, frameon=False)
plt.tight_layout()
plt.savefig('fig5_outliers.png', dpi=300, bbox_inches='tight')
plt.show()
print("  → fig5_outliers.png 저장 완료")

# ── 10. 최종 요약 출력 ────────────────────────────────────
print("\n" + "=" * 60)
print("EDA 완료 요약")
print("=" * 60)
print(f"샘플 크기       : n = {len(df_clean):,}")
print(f"결과변수 분포   : No AD = {len(g0):,} ({len(g0)/len(df_clean)*100:.1f}%)"
      f" / AD = {len(g1):,} ({len(g1)/len(df_clean)*100:.1f}%)")
print(f"결측치          : 없음 (완전 데이터셋)")
print(f"분석 변수 수    : {len(df_clean.columns)-1}개")
print(f"\n저장된 Figure 목록:")
for fname in ['fig1_distributions.png', 'fig2_binary_prevalence.png',
              'fig3_correlation_heatmap.png', 'fig4_clinical_boxplot.png',
              'fig5_outliers.png']:
    print(f"  • {fname}")

print("""
─────────────────────────────────────────
주요 EDA 소견 (해석 가이드)
─────────────────────────────────────────
1. MMSE: AD군에서 현저히 낮은 점수 분포 → 강력한 예측 인자 예상
2. FunctionalAssessment / ADL: 그룹 간 분포 차이 뚜렷
3. 클래스 불균형: 0=64.6% / 1=35.4% → 단계별 보정 필요
4. 결측치 없음 → 대체(imputation) 불필요
5. 이상치 비율 5% 미만 → 임상 데이터 정상 범위 내
─────────────────────────────────────────
""")
