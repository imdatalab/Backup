# ============================================================
# STEP 2: Univariate Analysis — Risk Factor Screening
# Dataset: Alzheimer's Disease Dataset (n=2,149)
# Purpose: Independent association between each variable
#          and Alzheimer's diagnosis
# Tests:   Mann-Whitney U (continuous), Chi-square / Fisher
#          (binary), Bonferroni correction, Effect sizes
# Standards: STROBE checklist compliant
# ============================================================

# ── 0. 라이브러리 ─────────────────────────────────────────
import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.ticker import MaxNLocator
import seaborn as sns
from scipy import stats
from scipy.stats import mannwhitneyu, chi2_contingency, fisher_exact
import os

SEED = 42
np.random.seed(SEED)

# 출판용 색상
COLORS = {
    'primary'  : '#0072B2',
    'positive' : '#D55E00',
    'negative' : '#0072B2',
    'sig'      : '#CC79A7',
    'ns'       : '#999999',
}
PALETTE = [COLORS['negative'], COLORS['positive']]

plt.rcParams.update({
    'font.family'      : 'DejaVu Sans',
    'font.size'        : 10,
    'axes.spines.top'  : False,
    'axes.spines.right': False,
    'figure.dpi'       : 150,
    'savefig.dpi'      : 300,
    'savefig.bbox'     : 'tight',
    'savefig.facecolor': 'white',
})

# ── 1. 데이터 로드 ─────────────────────────────────────────
print("=" * 60)
print("STEP 2: UNIVARIATE ANALYSIS")
print("=" * 60)

try:
    df = pd.read_csv('alzheimers.csv')
    print(f"[OK] 데이터 로드: {df.shape}")
except FileNotFoundError:
    print("[INFO] 시뮬레이션 데이터 사용")
    np.random.seed(SEED)
    n = 2149
    diag = np.random.choice([0,1], n, p=[0.647, 0.353])
    df = pd.DataFrame({
        'Age': np.where(diag==1,
                        np.random.normal(78, 8, n),
                        np.random.normal(73, 9, n)).clip(60,90).astype(int),
        'Gender': np.random.randint(0,2,n),
        'Ethnicity': np.random.choice([0,1,2,3],n),
        'EducationLevel': np.random.choice([0,1,2,3],n),
        'BMI': np.random.uniform(15,40,n),
        'Smoking': np.random.randint(0,2,n),
        'AlcoholConsumption': np.random.uniform(0,20,n),
        'PhysicalActivity': np.random.uniform(0,10,n),
        'DietQuality': np.random.uniform(0,10,n),
        'SleepQuality': np.random.uniform(4,10,n),
        'FamilyHistoryAlzheimers': np.random.randint(0,2,n),
        'CardiovascularDisease': np.random.randint(0,2,n),
        'Diabetes': np.random.randint(0,2,n),
        'Depression': np.random.randint(0,2,n),
        'HeadInjury': np.random.randint(0,2,n),
        'Hypertension': np.random.randint(0,2,n),
        'SystolicBP': np.random.randint(90,180,n),
        'DiastolicBP': np.random.randint(60,120,n),
        'CholesterolTotal': np.random.uniform(150,300,n),
        'CholesterolLDL': np.random.uniform(50,200,n),
        'CholesterolHDL': np.random.uniform(20,100,n),
        'CholesterolTriglycerides': np.random.uniform(50,400,n),
        'MMSE': np.where(diag==1,
                         np.random.normal(10,6,n).clip(0,30),
                         np.random.normal(20,5,n).clip(0,30)),
        'FunctionalAssessment': np.where(diag==1,
                         np.random.normal(3.5,2,n).clip(0,10),
                         np.random.normal(6.5,2,n).clip(0,10)),
        'MemoryComplaints': np.random.randint(0,2,n),
        'BehavioralProblems': np.random.randint(0,2,n),
        'ADL': np.random.uniform(0,10,n),
        'Confusion': np.random.randint(0,2,n),
        'Disorientation': np.random.randint(0,2,n),
        'PersonalityChanges': np.random.randint(0,2,n),
        'DifficultyCompletingTasks': np.random.randint(0,2,n),
        'Forgetfulness': np.random.randint(0,2,n),
        'Diagnosis': diag,
    })

DROP = ['PatientID', 'DoctorInCharge']
df   = df.drop(columns=DROP, errors='ignore')

CONTINUOUS_VARS = [
    'Age', 'BMI', 'AlcoholConsumption', 'PhysicalActivity',
    'DietQuality', 'SleepQuality', 'SystolicBP', 'DiastolicBP',
    'CholesterolTotal', 'CholesterolLDL', 'CholesterolHDL',
    'CholesterolTriglycerides', 'MMSE', 'FunctionalAssessment', 'ADL'
]
BINARY_VARS = [
    'Gender', 'Smoking', 'FamilyHistoryAlzheimers', 'CardiovascularDisease',
    'Diabetes', 'Depression', 'HeadInjury', 'Hypertension',
    'MemoryComplaints', 'BehavioralProblems', 'Confusion',
    'Disorientation', 'PersonalityChanges', 'DifficultyCompletingTasks',
    'Forgetfulness'
]
ORDINAL_VARS = ['Ethnicity', 'EducationLevel']
TARGET = 'Diagnosis'

g0 = df[df[TARGET] == 0]
g1 = df[df[TARGET] == 1]

# Bonferroni 보정 임계값
N_TESTS   = len(CONTINUOUS_VARS) + len(BINARY_VARS) + len(ORDINAL_VARS)
ALPHA_ADJ = 0.05 / N_TESTS
print(f"\nBonferroni 보정: α = 0.05 / {N_TESTS} = {ALPHA_ADJ:.4f}")

# ── 2. 연속형 변수 분석 ────────────────────────────────────
def rank_biserial_r(u_stat, n1, n2):
    """Effect size for Mann-Whitney U (rank-biserial correlation)"""
    return 1 - (2 * u_stat) / (n1 * n2)

print("\n" + "─" * 40)
print("연속형 변수 분석 (Mann-Whitney U)")
print("─" * 40)

cont_results = []
for col in CONTINUOUS_VARS:
    d0 = g0[col].dropna().values
    d1 = g1[col].dropna().values

    # 정규성 검정 (D'Agostino-Pearson)
    _, p_norm = stats.normaltest(df[col].dropna())

    # Mann-Whitney U
    u_stat, p_mw = mannwhitneyu(d0, d1, alternative='two-sided')

    # Effect size: rank-biserial r
    r_rb = rank_biserial_r(u_stat, len(d0), len(d1))

    # 기술통계
    med0, q1_0, q3_0 = np.median(d0), np.percentile(d0,25), np.percentile(d0,75)
    med1, q1_1, q3_1 = np.median(d1), np.percentile(d1,25), np.percentile(d1,75)

    cont_results.append({
        'Variable'     : col,
        'No_AD_Med_IQR': f"{med0:.1f} [{q1_0:.1f}–{q3_0:.1f}]",
        'AD_Med_IQR'   : f"{med1:.1f} [{q1_1:.1f}–{q3_1:.1f}]",
        'U_statistic'  : round(u_stat, 1),
        'p_value'      : p_mw,
        'r_rb'         : round(r_rb, 3),
        'Effect_size'  : ('Large'  if abs(r_rb)>=0.5 else
                          'Medium' if abs(r_rb)>=0.3 else 'Small'),
        'Significant'  : p_mw < ALPHA_ADJ,
        'Normality_p'  : round(p_norm, 4),
    })

cont_df = pd.DataFrame(cont_results).sort_values('p_value')

print("\n연속형 변수 단변량 분석 결과:")
print(cont_df[['Variable','No_AD_Med_IQR','AD_Med_IQR',
               'U_statistic','p_value','r_rb','Effect_size',
               'Significant']].to_string(index=False))

# ── 3. 범주형 변수 분석 ────────────────────────────────────
def odds_ratio_ci(a, b, c, d, alpha=0.05):
    """
    2×2 table OR with Woolf logit CI
    a=AD+/exposure+, b=AD-/exposure+
    c=AD+/exposure-, d=AD-/exposure-
    """
    if 0 in [a, b, c, d]:
        a += 0.5; b += 0.5; c += 0.5; d += 0.5  # Haldane correction
    or_val = (a * d) / (b * c)
    se_log = np.sqrt(1/a + 1/b + 1/c + 1/d)
    z = stats.norm.ppf(1 - alpha/2)
    ci_lo  = np.exp(np.log(or_val) - z * se_log)
    ci_hi  = np.exp(np.log(or_val) + z * se_log)
    return or_val, ci_lo, ci_hi

def cramers_v(contingency):
    """Cramér's V effect size"""
    chi2 = chi2_contingency(contingency)[0]
    n    = contingency.sum()
    r, k = contingency.shape
    return np.sqrt(chi2 / (n * (min(r,k) - 1)))

print("\n" + "─" * 40)
print("범주형 변수 분석 (Chi-square / Fisher)")
print("─" * 40)

cat_results = []
for col in BINARY_VARS + ORDINAL_VARS:
    is_binary = col in BINARY_VARS

    if is_binary:
        n_exp_d1   = g1[col].sum()
        n_noexp_d1 = len(g1) - n_exp_d1
        n_exp_d0   = g0[col].sum()
        n_noexp_d0 = len(g0) - n_exp_d0

        # 2×2 contingency
        ct = np.array([[n_exp_d1,   n_exp_d0],
                       [n_noexp_d1, n_noexp_d0]])

        # Fisher's exact test (모두 사용; 샘플 작을 때 정확)
        if np.any(ct < 5):
            _, p_val = fisher_exact(ct)
            test_used = 'Fisher'
        else:
            chi2, p_val, _, _ = chi2_contingency(ct, correction=False)
            test_used = 'Chi-sq'

        # OR & 95% CI
        or_val, ci_lo, ci_hi = odds_ratio_ci(
            n_exp_d1, n_exp_d0, n_noexp_d1, n_noexp_d0)

        cv = cramers_v(ct)

        prev_d0 = n_exp_d0 / len(g0) * 100
        prev_d1 = n_exp_d1 / len(g1) * 100

        cat_results.append({
            'Variable'   : col,
            'No_AD_%'    : f"{prev_d0:.1f}%",
            'AD_%'       : f"{prev_d1:.1f}%",
            'Test'       : test_used,
            'OR'         : round(or_val, 2),
            '95%_CI'     : f"[{ci_lo:.2f}–{ci_hi:.2f}]",
            'p_value'    : p_val,
            "Cramér's_V" : round(cv, 3),
            'Significant': p_val < ALPHA_ADJ,
        })
    else:
        # Ordinal: Chi-square
        ct = pd.crosstab(df[col], df[TARGET]).values
        chi2, p_val, _, _ = chi2_contingency(ct)
        cv = cramers_v(ct)
        cat_results.append({
            'Variable'   : col,
            'No_AD_%'    : '—',
            'AD_%'       : '—',
            'Test'       : 'Chi-sq',
            'OR'         : '—',
            '95%_CI'     : '—',
            'p_value'    : p_val,
            "Cramér's_V" : round(cv, 3),
            'Significant': p_val < ALPHA_ADJ,
        })

cat_df = pd.DataFrame(cat_results).sort_values('p_value')

print("\n범주형 변수 단변량 분석 결과:")
print(cat_df[['Variable','No_AD_%','AD_%','Test',
              'OR','95%_CI','p_value',"Cramér's_V",'Significant']].to_string(index=False))

# ── 4. 통합 결과 정리 ──────────────────────────────────────
sig_continuous   = cont_df[cont_df['Significant']]['Variable'].tolist()
sig_categorical  = cat_df[cat_df['Significant']]['Variable'].tolist()
sig_all          = sig_continuous + sig_categorical

print(f"\n유의한 변수 (Bonferroni α={ALPHA_ADJ:.4f}) :")
print(f"  연속형  ({len(sig_continuous)}개): {sig_continuous}")
print(f"  범주형  ({len(sig_categorical)}개): {sig_categorical}")
print(f"  합계    ({len(sig_all)}개)")

# ── 5. Figure 6: Volcano-style Plot ──────────────────────
print("\n[Figure 6] Volcano Plot 생성 중...")

plot_rows = []
for _, r in cont_df.iterrows():
    plot_rows.append({
        'Variable': r['Variable'],
        'neg_log10_p': -np.log10(max(r['p_value'], 1e-15)),
        'effect': abs(r['r_rb']),
        'sig': r['Significant'],
        'type': 'Continuous'
    })
for _, r in cat_df.iterrows():
    if isinstance(r['OR'], (int, float)):
        eff = abs(np.log2(float(r['OR']))) if r['OR'] not in ['—', 0] else 0
    else:
        eff = 0
    plot_rows.append({
        'Variable': r['Variable'],
        'neg_log10_p': -np.log10(max(r['p_value'], 1e-15)),
        'effect': float(r["Cramér's_V"]),
        'sig': r['Significant'],
        'type': 'Categorical'
    })

plot_df = pd.DataFrame(plot_rows)

fig6, ax6 = plt.subplots(figsize=(13, 7))

for sig, color, label, size in [
    (True,  COLORS['positive'], 'Significant (Bonferroni)', 80),
    (False, COLORS['ns'],       'Non-significant',          40)
]:
    sub = plot_df[plot_df['sig'] == sig]
    ax6.scatter(sub['effect'], sub['neg_log10_p'],
                c=color, s=size, alpha=0.8, edgecolors='white',
                linewidths=0.5, label=label, zorder=3)

# 유의 임계선
ax6.axhline(-np.log10(ALPHA_ADJ), color='red', ls='--', lw=1.2, alpha=0.7,
            label=f'Bonferroni threshold (p={ALPHA_ADJ:.4f})')
ax6.axhline(-np.log10(0.05),      color='gray',ls=':',  lw=1.0, alpha=0.7,
            label='p=0.05')

# 유의 변수 레이블
for _, row in plot_df[plot_df['sig']].iterrows():
    ax6.annotate(
        row['Variable'],
        xy=(row['effect'], row['neg_log10_p']),
        xytext=(5, 3), textcoords='offset points',
        fontsize=7.5, color='black',
        arrowprops=dict(arrowstyle='-', color='gray',
                        lw=0.5, alpha=0.6)
    )

ax6.set_xlabel('Effect Size (|rank-biserial r| or Cramér\'s V)',
               fontsize=10)
ax6.set_ylabel('−log₁₀(p-value)', fontsize=10)
ax6.set_title('Figure 6. Univariate Association: Volcano Plot\n'
              '(All variables vs. Alzheimer\'s Diagnosis)',
              fontsize=12, fontweight='bold')
ax6.legend(fontsize=8, frameon=True, framealpha=0.9)
plt.tight_layout()
plt.savefig('fig6_volcano_plot.png', dpi=300, bbox_inches='tight')
plt.show()
print("  → fig6_volcano_plot.png 저장 완료")

# ── 6. Figure 7: OR Forest Plot (이진형 변수) ─────────────
print("[Figure 7] Forest Plot (Binary Variables OR) 생성 중...")

forest_df = cat_df[cat_df['OR'] != '—'].copy()
forest_df['OR_num']    = pd.to_numeric(forest_df['OR'],    errors='coerce')
forest_df['CI_lo_num'] = forest_df['95%_CI'].apply(
    lambda x: float(x.strip('[]').split('–')[0]) if x != '—' else np.nan)
forest_df['CI_hi_num'] = forest_df['95%_CI'].apply(
    lambda x: float(x.strip('[]').split('–')[1]) if x != '—' else np.nan)
forest_df = forest_df.dropna(subset=['OR_num']).sort_values('OR_num')

fig7, ax7 = plt.subplots(figsize=(10, 8))
y_pos  = range(len(forest_df))
colors = [COLORS['positive'] if r['Significant'] else COLORS['ns']
          for _, r in forest_df.iterrows()]

ax7.barh(list(y_pos), forest_df['OR_num'],
         xerr=[forest_df['OR_num'] - forest_df['CI_lo_num'],
               forest_df['CI_hi_num'] - forest_df['OR_num']],
         color=colors, alpha=0.75, height=0.55,
         error_kw={'elinewidth': 1.5, 'capsize': 4, 'ecolor': 'black'})

ax7.axvline(1.0, color='black', lw=1.2, ls='--', alpha=0.7)
ax7.set_yticks(list(y_pos))
ax7.set_yticklabels(forest_df['Variable'], fontsize=9)
ax7.set_xlabel('Odds Ratio (95% CI)', fontsize=10)
ax7.set_title('Figure 7. Unadjusted Odds Ratios for Binary Risk Factors\n'
              '(ref = absence of risk factor)',
              fontsize=12, fontweight='bold')

# OR 값 텍스트
for i, (_, row) in enumerate(forest_df.iterrows()):
    ax7.text(row['CI_hi_num'] + 0.03, i,
             f"{row['OR_num']:.2f} {row['95%_CI']}",
             va='center', fontsize=7.5)

# 범례
from matplotlib.patches import Patch
legend_elements = [
    Patch(facecolor=COLORS['positive'], alpha=0.75,
          label=f'Significant (Bonferroni p<{ALPHA_ADJ:.4f})'),
    Patch(facecolor=COLORS['ns'], alpha=0.75, label='Non-significant')
]
ax7.legend(handles=legend_elements, fontsize=8, frameon=False)
plt.tight_layout()
plt.savefig('fig7_forest_plot.png', dpi=300, bbox_inches='tight')
plt.show()
print("  → fig7_forest_plot.png 저장 완료")

# ── 7. Publication-ready Table 2 ─────────────────────────
print("\n" + "─" * 40)
print("TABLE 2: Univariate Analysis Results")
print("─" * 40)

# 연속형 결과
print("\n[연속형 변수]")
cont_pub = cont_df[['Variable','No_AD_Med_IQR','AD_Med_IQR',
                    'U_statistic','p_value','r_rb','Effect_size']].copy()
cont_pub['p_value'] = cont_pub['p_value'].apply(
    lambda p: '<0.001' if p < 0.001 else f'{p:.3f}')
print(cont_pub.to_string(index=False))

# 범주형 결과
print("\n[범주형 변수]")
cat_pub = cat_df[['Variable','No_AD_%','AD_%','Test',
                  'OR','95%_CI','p_value',"Cramér's_V"]].copy()
cat_pub['p_value'] = cat_pub['p_value'].apply(
    lambda p: '<0.001' if p < 0.001 else f'{p:.3f}')
print(cat_pub.to_string(index=False))

# 다음 단계 변수 목록 저장
next_step_vars = sig_all.copy()
print(f"\n[다음 단계 진입 변수] (p < 0.1 기준 확대 시)")
liberal_cont = cont_df[cont_df['p_value'].astype(str).apply(
    lambda x: float(x) if x != '<0.001' else 0.0001) < 0.1]['Variable'].tolist()
liberal_cat  = cat_df[cat_df['p_value'].apply(
    lambda p: p < 0.1)]['Variable'].tolist()
print(f"  → {list(set(liberal_cont + liberal_cat))}")

print("\n" + "=" * 60)
print("단변량 분석 완료")
print(f"저장된 Figure: fig6_volcano_plot.png, fig7_forest_plot.png")
print("=" * 60)
