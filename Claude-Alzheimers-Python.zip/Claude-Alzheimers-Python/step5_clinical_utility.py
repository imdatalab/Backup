# ============================================================
# STEP 5: Clinical Utility Validation
# Dataset: Alzheimer's Disease Dataset (n=2,149)
# Purpose: Validate clinical usefulness beyond AUROC
# Methods: Decision Curve Analysis (DCA),
#          Calibration (plot + Brier score + Hosmer-Lemeshow),
#          NRI (Net Reclassification Improvement),
#          IDI (Integrated Discrimination Improvement),
#          Threshold analysis, Clinical impact curve
# ============================================================

# ── 0. 라이브러리 ─────────────────────────────────────────
import warnings
warnings.filterwarnings('ignore')

import pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import Patch
import seaborn as sns
from scipy import stats
from scipy.stats import chi2

# Sklearn
from sklearn.model_selection    import StratifiedKFold, train_test_split
from sklearn.preprocessing      import StandardScaler
from sklearn.linear_model       import LogisticRegression
from sklearn.ensemble           import RandomForestClassifier
from sklearn.metrics            import (roc_auc_score, roc_curve,
                                         brier_score_loss,
                                         confusion_matrix)
from sklearn.calibration        import calibration_curve

try:
    from xgboost import XGBClassifier
    HAS_XGB = True
except ImportError:
    HAS_XGB = False

SEED = 42
np.random.seed(SEED)

COLORS = {
    'primary'  : '#0072B2',
    'positive' : '#D55E00',
    'negative' : '#009E73',
    'neutral'  : '#E69F00',
    'highlight': '#CC79A7',
    'ns'       : '#999999',
    'red'      : '#CC0000',
}

plt.rcParams.update({
    'font.family'      : 'DejaVu Sans',
    'font.size'        : 10,
    'axes.spines.top'  : False,
    'axes.spines.right': False,
    'figure.dpi'       : 150,
    'savefig.dpi'      : 300,
    'savefig.bbox'     : 'tight',
    'savefig.facecolor': 'white',
})

# ── 1. 데이터 로드 ─────────────────────────────────────────
print("=" * 60)
print("STEP 5: CLINICAL UTILITY VALIDATION")
print("=" * 60)

try:
    df = pd.read_csv('alzheimers.csv')
    print(f"[OK] 데이터 로드: {df.shape}")
except FileNotFoundError:
    print("[INFO] 시뮬레이션 데이터 사용")
    np.random.seed(SEED)
    n = 2149
    diag = np.random.choice([0,1], n, p=[0.647,0.353])
    df = pd.DataFrame({
        'Age': np.where(diag==1, np.random.normal(78,8,n),
                        np.random.normal(73,9,n)).clip(60,90).astype(int),
        'MMSE': np.where(diag==1,
                         np.random.normal(10,6,n).clip(0,30),
                         np.random.normal(20,5,n).clip(0,30)),
        'FunctionalAssessment': np.where(diag==1,
                         np.random.normal(3.5,2,n).clip(0,10),
                         np.random.normal(6.5,2,n).clip(0,10)),
        'ADL': np.where(diag==1,
                         np.random.normal(3,2,n).clip(0,10),
                         np.random.normal(7,2,n).clip(0,10)),
        'MemoryComplaints': np.where(diag==1,
                         np.random.binomial(1,0.6,n),
                         np.random.binomial(1,0.15,n)),
        'BehavioralProblems': np.random.randint(0,2,n),
        'FamilyHistoryAlzheimers': np.random.randint(0,2,n),
        'Depression': np.random.randint(0,2,n),
        'BMI': np.random.uniform(15,40,n),
        'Smoking': np.random.randint(0,2,n),
        'PhysicalActivity': np.random.uniform(0,10,n),
        'SleepQuality': np.random.uniform(4,10,n),
        'Gender': np.random.randint(0,2,n),
        'Diabetes': np.random.randint(0,2,n),
        'Hypertension': np.random.randint(0,2,n),
        'HeadInjury': np.random.randint(0,2,n),
        'Confusion': np.random.randint(0,2,n),
        'Disorientation': np.random.randint(0,2,n),
        'Forgetfulness': np.random.randint(0,2,n),
        'Diagnosis': diag,
    })

DROP = ['PatientID', 'DoctorInCharge']
df   = df.drop(columns=DROP, errors='ignore')
TARGET   = 'Diagnosis'
FEATURES = [c for c in df.columns if c != TARGET]

X = df[FEATURES].values
y = df[TARGET].values

# ── 2. 모델 학습 (3개 모델 준비) ──────────────────────────
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=SEED
)
scaler     = StandardScaler()
X_tr_sc    = scaler.fit_transform(X_tr)
X_te_sc    = scaler.transform(X_te)

# 기준 모델 (Logistic Regression)
lr = LogisticRegression(C=1.0, max_iter=1000, random_state=SEED,
                         class_weight='balanced')
lr.fit(X_tr_sc, y_tr)
prob_lr = lr.predict_proba(X_te_sc)[:, 1]

# 기본 모델 (Random Forest)
rf = RandomForestClassifier(n_estimators=300, max_depth=8,
                              class_weight='balanced',
                              n_jobs=-1, random_state=SEED)
rf.fit(X_tr_sc, y_tr)
prob_rf = rf.predict_proba(X_te_sc)[:, 1]

# 최종 모델 (XGBoost or RF)
if HAS_XGB:
    scale_pos = sum(y_tr==0) / sum(y_tr==1)
    xgb = XGBClassifier(
        n_estimators=300, max_depth=5, learning_rate=0.05,
        scale_pos_weight=scale_pos,
        eval_metric='auc', use_label_encoder=False,
        random_state=SEED, verbosity=0
    )
    xgb.fit(X_tr_sc, y_tr)
    prob_best = xgb.predict_proba(X_te_sc)[:, 1]
    best_name = 'XGBoost'
else:
    prob_best = prob_rf
    best_name = 'RF'

# 유병률 계산
prevalence = y.mean()
n_test     = len(y_te)
print(f"\n테스트 세트: n={n_test} | AD prevalence={prevalence:.3f}")

# ── 3. FUNCTION: Decision Curve Analysis ─────────────────
def decision_curve_analysis(y_true, y_prob_dict, thresholds=None):
    """
    DCA: Net Benefit 계산
    net_benefit = (TP/n) - (FP/n) * (pt/(1-pt))
    where pt = probability threshold
    """
    if thresholds is None:
        thresholds = np.linspace(0.01, 0.99, 200)

    results = {}
    n = len(y_true)

    # 기준선 1: 모두 양성으로 분류
    results['All positive'] = []
    for pt in thresholds:
        tp = y_true.sum()
        fp = (1 - y_true).sum()
        nb = tp/n - fp/n * pt/(1-pt)
        results['All positive'].append(nb)

    # 기준선 2: 모두 음성 (NB=0)
    results['All negative'] = [0] * len(thresholds)

    # 각 모델
    for name, prob in y_prob_dict.items():
        nbs = []
        for pt in thresholds:
            y_pred_t = (prob >= pt).astype(int)
            tp = ((y_pred_t == 1) & (y_true == 1)).sum()
            fp = ((y_pred_t == 1) & (y_true == 0)).sum()
            nb = tp/n - fp/n * pt/(1-pt)
            nbs.append(nb)
        results[name] = nbs

    return pd.DataFrame(results, index=thresholds)

# ── 4. Figure 14: Decision Curve Analysis ────────────────
print("\n[Figure 14] Decision Curve Analysis 생성 중...")

prob_dict = {
    'Logistic Regression': prob_lr,
    'Random Forest'      : prob_rf,
    best_name            : prob_best,
}

dca_df = decision_curve_analysis(y_te, prob_dict)
thresholds = dca_df.index.values

fig14, ax14 = plt.subplots(figsize=(10, 7))

line_styles = {
    'All positive'       : ('--', COLORS['ns'],      0.6, 1.2),
    'All negative'       : ('--', 'black',            0.6, 1.2),
    'Logistic Regression': ('-',  COLORS['positive'], 0.8, 1.8),
    'Random Forest'      : ('-',  COLORS['primary'],  0.8, 1.8),
    best_name            : ('-',  COLORS['highlight'],0.9, 2.5),
}

for col in dca_df.columns:
    ls, color, alpha, lw = line_styles.get(
        col, ('-', COLORS['ns'], 0.6, 1.2))
    ax14.plot(thresholds, dca_df[col],
              ls=ls, color=color, alpha=alpha, lw=lw,
              label=col)

ax14.axhline(0, color='black', lw=0.5, alpha=0.4)
ax14.set_xlim(0, 0.8)
ax14.set_ylim(-0.05, max(dca_df[best_name].max() * 1.2, 0.2))
ax14.set_xlabel('Threshold Probability', fontsize=11)
ax14.set_ylabel('Net Benefit', fontsize=11)
ax14.set_title(
    'Figure 14. Decision Curve Analysis\n'
    '(Net clinical benefit at each probability threshold)',
    fontsize=12, fontweight='bold'
)
ax14.legend(fontsize=9, frameon=True, framealpha=0.9)

# 임상적으로 의미 있는 구간 표시 (5%~30%)
ax14.axvspan(0.05, 0.30, alpha=0.06, color='green',
             label='Clinical decision zone')
ax14.text(0.17, ax14.get_ylim()[1]*0.92,
          'Clinical\ndecision zone\n(5–30%)',
          ha='center', fontsize=8, color='darkgreen')

plt.tight_layout()
plt.savefig('fig14_DCA.png', dpi=300, bbox_inches='tight')
plt.show()
print("  → fig14_DCA.png 저장 완료")

# ── 5. Figure 15: Calibration Plots ──────────────────────
print("[Figure 15] Calibration Plot 생성 중...")

fig15, axes15 = plt.subplots(1, 3, figsize=(16, 5))
model_probs = [
    ('Logistic Regression', prob_lr),
    ('Random Forest',       prob_rf),
    (best_name,             prob_best),
]
colors15 = [COLORS['positive'], COLORS['primary'], COLORS['highlight']]

for ax, (name, prob), color in zip(axes15, model_probs, colors15):
    frac_pos, mean_pred = calibration_curve(y_te, prob, n_bins=10)
    brier = brier_score_loss(y_te, prob)
    auroc = roc_auc_score(y_te, prob)

    # 완벽 보정선
    ax.plot([0,1],[0,1], 'k--', lw=1.0, alpha=0.6, label='Perfect calibration')

    # 실제 보정 곡선
    ax.plot(mean_pred, frac_pos, 'o-',
            color=color, lw=2.0, ms=6, alpha=0.85,
            label=f'Observed\nBrier={brier:.3f}')

    # 95% CI (bootstrap)
    np.random.seed(SEED)
    boot_curves = []
    for _ in range(200):
        idx = np.random.choice(n_test, n_test, replace=True)
        if len(np.unique(y_te[idx])) < 2:
            continue
        fp_b, mp_b = calibration_curve(y_te[idx], prob[idx], n_bins=10)
        # 보간하여 동일 격자에 맞춤
        if len(mp_b) == len(mean_pred):
            boot_curves.append(fp_b)

    if len(boot_curves) >= 100:
        boot_arr = np.array(boot_curves)
        ci_lo_c  = np.percentile(boot_arr, 2.5, axis=0)
        ci_hi_c  = np.percentile(boot_arr, 97.5, axis=0)
        ax.fill_between(mean_pred, ci_lo_c, ci_hi_c,
                        alpha=0.2, color=color, label='95% CI')

    ax.set_xlabel('Mean Predicted Probability', fontsize=9)
    ax.set_ylabel('Fraction of Positives', fontsize=9)
    ax.set_title(f'{name}\n(AUROC={auroc:.3f}, Brier={brier:.3f})',
                 fontsize=10, fontweight='bold')
    ax.legend(fontsize=8, frameon=False)
    ax.set_xlim(-0.02, 1.02)
    ax.set_ylim(-0.02, 1.02)

fig15.suptitle('Figure 15. Calibration Plots (10-bin, Bootstrap 95% CI)',
               fontsize=12, fontweight='bold')
plt.tight_layout()
plt.savefig('fig15_calibration.png', dpi=300, bbox_inches='tight')
plt.show()
print("  → fig15_calibration.png 저장 완료")

# ── 6. NRI 및 IDI 계산 ────────────────────────────────────
def nri_idi(y_true, prob_new, prob_ref, threshold=0.5):
    """
    Net Reclassification Improvement (NRI)
    Integrated Discrimination Improvement (IDI)
    Pencina et al. 2008 (Statistics in Medicine)
    """
    y = np.array(y_true)
    p_new = np.array(prob_new)
    p_ref = np.array(prob_ref)

    events    = y == 1
    nonevents = y == 0

    # Categorical NRI
    up_ev   = np.sum((p_new > threshold) & (p_ref <= threshold) & events)
    down_ev = np.sum((p_new <= threshold) & (p_ref > threshold) & events)
    up_nev  = np.sum((p_new > threshold) & (p_ref <= threshold) & nonevents)
    down_nev= np.sum((p_new <= threshold) & (p_ref > threshold) & nonevents)

    nri_ev  = (up_ev   - down_ev)  / events.sum()
    nri_nev = (down_nev - up_nev)  / nonevents.sum()
    nri     = nri_ev + nri_nev

    # Continuous NRI
    up_ev_c   = np.sum((p_new > p_ref) & events)
    down_ev_c = np.sum((p_new < p_ref) & events)
    up_nev_c  = np.sum((p_new > p_ref) & nonevents)
    down_nev_c= np.sum((p_new < p_ref) & nonevents)

    nri_c_ev  = (up_ev_c   - down_ev_c)  / events.sum()
    nri_c_nev = (down_nev_c - up_nev_c)  / nonevents.sum()
    nri_c     = nri_c_ev + nri_c_nev

    # IDI
    is_ev  = p_new[events].mean()    - p_ref[events].mean()
    is_nev = p_new[nonevents].mean() - p_ref[nonevents].mean()
    idi    = is_ev - is_nev

    # Bootstrap p-values
    np.random.seed(SEED)
    n_boot = 1000
    nri_boots, idi_boots = [], []
    for _ in range(n_boot):
        idx = np.random.choice(len(y), len(y), replace=True)
        y_b, pn_b, pr_b = y[idx], p_new[idx], p_ref[idx]
        ev_b, nev_b = y_b==1, y_b==0
        if ev_b.sum() < 5 or nev_b.sum() < 5:
            continue
        u_ev = np.sum((pn_b>pr_b) & ev_b) / ev_b.sum()
        d_ev = np.sum((pn_b<pr_b) & ev_b) / ev_b.sum()
        u_nv = np.sum((pn_b>pr_b) & nev_b) / nev_b.sum()
        d_nv = np.sum((pn_b<pr_b) & nev_b) / nev_b.sum()
        nri_boots.append((u_ev-d_ev) + (d_nv-u_nv))
        idi_boots.append(
            (pn_b[ev_b].mean() - pr_b[ev_b].mean()) -
            (pn_b[nev_b].mean() - pr_b[nev_b].mean())
        )

    nri_ci = (np.percentile(nri_boots, 2.5),
              np.percentile(nri_boots, 97.5))
    idi_ci = (np.percentile(idi_boots, 2.5),
              np.percentile(idi_boots, 97.5))
    p_nri  = 2 * min((np.array(nri_boots) > 0).mean(),
                     (np.array(nri_boots) < 0).mean())
    p_idi  = 2 * min((np.array(idi_boots) > 0).mean(),
                     (np.array(idi_boots) < 0).mean())

    return {
        'NRI_cat'    : round(nri, 4),
        'NRI_cont'   : round(nri_c, 4),
        'NRI_CI'     : (round(nri_ci[0],4), round(nri_ci[1],4)),
        'NRI_p'      : round(p_nri, 4),
        'IDI'        : round(idi, 4),
        'IDI_CI'     : (round(idi_ci[0],4), round(idi_ci[1],4)),
        'IDI_p'      : round(p_idi, 4),
        'IS_event'   : round(is_ev, 4),
        'IS_nonevent': round(is_nev, 4),
    }

print("\n" + "─" * 40)
print("NRI / IDI: LR → RF 개선도")
print("─" * 40)
nri_lr_rf = nri_idi(y_te, prob_rf, prob_lr)
for k, v in nri_lr_rf.items():
    print(f"  {k}: {v}")

print("\nNRI / IDI: RF → Best 개선도")
nri_rf_best = nri_idi(y_te, prob_best, prob_rf)
for k, v in nri_rf_best.items():
    print(f"  {k}: {v}")

# ── 7. Figure 16: Clinical Impact Curve ──────────────────
print("\n[Figure 16] Clinical Impact Curve 생성 중...")

thresholds_ci = np.linspace(0.01, 0.99, 200)
fig16, (ax16a, ax16b) = plt.subplots(1, 2, figsize=(14, 6))

for ax, prob, name, color in [
    (ax16a, prob_rf,   'Random Forest', COLORS['primary']),
    (ax16b, prob_best, best_name,       COLORS['highlight'])
]:
    n_pos_screen = []
    n_true_pos   = []
    for pt in thresholds_ci:
        y_pred_t  = (prob >= pt).astype(int)
        screen_n  = y_pred_t.sum()
        true_pos  = ((y_pred_t == 1) & (y_te == 1)).sum()
        n_pos_screen.append(screen_n * 1000 / n_test)
        n_true_pos.append(true_pos * 1000 / n_test)

    ax.plot(thresholds_ci, n_pos_screen,
            color=COLORS['ns'], lw=1.8, alpha=0.7,
            label='Flagged for further eval')
    ax.plot(thresholds_ci, n_true_pos,
            color=color, lw=2.2,
            label='True positives (AD confirmed)')

    ax.set_xlabel('Threshold Probability', fontsize=10)
    ax.set_ylabel('Number per 1,000 patients', fontsize=10)
    ax.set_title(f'Clinical Impact Curve\n{name}',
                 fontsize=11, fontweight='bold')
    ax.legend(fontsize=8.5, frameon=False)
    ax.set_xlim(0, 0.8)

fig16.suptitle('Figure 16. Clinical Impact Curve\n'
               '(Number flagged vs. true positives per 1,000 patients)',
               fontsize=12, fontweight='bold')
plt.tight_layout()
plt.savefig('fig16_clinical_impact.png', dpi=300, bbox_inches='tight')
plt.show()
print("  → fig16_clinical_impact.png 저장 완료")

# ── 8. Figure 17: Optimal Threshold Analysis ─────────────
print("[Figure 17] 최적 임계값 분석 생성 중...")

fig17, axes17 = plt.subplots(1, 2, figsize=(14, 6))
model_eval = [('Random Forest', prob_rf, COLORS['primary']),
              (best_name, prob_best, COLORS['highlight'])]

for ax, (name, prob, color) in zip(axes17, model_eval):
    thresholds_t = np.linspace(0.01, 0.99, 200)
    sens_list, spec_list, f1_list, j_list = [], [], [], []

    for pt in thresholds_t:
        yp = (prob >= pt).astype(int)
        tn, fp, fn, tp = confusion_matrix(y_te, yp,
                                           labels=[0,1]).ravel()
        sens = tp/(tp+fn) if (tp+fn)>0 else 0
        spec = tn/(tn+fp) if (tn+fp)>0 else 0
        ppv  = tp/(tp+fp) if (tp+fp)>0 else 0
        f1   = 2*ppv*sens/(ppv+sens) if (ppv+sens)>0 else 0
        j    = sens + spec - 1
        sens_list.append(sens); spec_list.append(spec)
        f1_list.append(f1); j_list.append(j)

    ax.plot(thresholds_t, sens_list, '-',
            color=COLORS['positive'], lw=1.8, alpha=0.8, label='Sensitivity')
    ax.plot(thresholds_t, spec_list, '-',
            color=COLORS['primary'], lw=1.8, alpha=0.8, label='Specificity')
    ax.plot(thresholds_t, f1_list, '-',
            color=COLORS['neutral'], lw=1.8, alpha=0.8, label='F1-score')
    ax.plot(thresholds_t, j_list, '-',
            color=color, lw=2.0, label="Youden's J")

    # 최적 임계값 (Youden's J)
    best_t = thresholds_t[np.argmax(j_list)]
    ax.axvline(best_t, color='red', ls='--', lw=1.3, alpha=0.8,
               label=f"Optimal threshold={best_t:.2f}")
    ax.scatter([best_t], [max(j_list)],
               color='red', s=60, zorder=5)

    ax.set_xlabel('Threshold Probability', fontsize=10)
    ax.set_ylabel('Score', fontsize=10)
    ax.set_title(f'{name}\nOptimal threshold = {best_t:.2f}',
                 fontsize=11, fontweight='bold')
    ax.legend(fontsize=8, frameon=False)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1.05)

fig17.suptitle("Figure 17. Threshold Optimization (Youden's J Index)",
               fontsize=12, fontweight='bold')
plt.tight_layout()
plt.savefig('fig17_threshold_optimization.png', dpi=300, bbox_inches='tight')
plt.show()
print("  → fig17_threshold_optimization.png 저장 완료")

# ── 9. Publication-ready Table 5 ─────────────────────────
print("\n" + "─" * 60)
print("TABLE 5: Clinical Utility Summary")
print("─" * 60)

table5_rows = []
for name, prob in [('Logistic Regression', prob_lr),
                   ('Random Forest',       prob_rf),
                   (best_name,             prob_best)]:
    brier  = brier_score_loss(y_te, prob)
    auroc  = roc_auc_score(y_te, prob)
    frac_p, mean_p = calibration_curve(y_te, prob, n_bins=10)
    cal_slope = np.polyfit(mean_p, frac_p, 1)[0]

    # DCA: NB at threshold=0.2
    pt = 0.20
    yp = (prob >= pt).astype(int)
    tp = ((yp==1)&(y_te==1)).sum()
    fp = ((yp==1)&(y_te==0)).sum()
    nb_02 = tp/n_test - fp/n_test * pt/(1-pt)

    table5_rows.append({
        'Model'          : name,
        'AUROC'          : f'{auroc:.3f}',
        'Brier Score'    : f'{brier:.3f}',
        'Cal. Slope'     : f'{cal_slope:.3f}',
        'Net Benefit@0.2': f'{nb_02:.4f}',
    })

table5 = pd.DataFrame(table5_rows)
print(table5.to_string(index=False))

# NRI/IDI 요약
print("\n[NRI/IDI: LR→RF]")
print(f"  NRI (continuous) = {nri_lr_rf['NRI_cont']:.4f} "
      f"95%CI ({nri_lr_rf['NRI_CI'][0]:.4f}–{nri_lr_rf['NRI_CI'][1]:.4f}) "
      f"p={nri_lr_rf['NRI_p']:.4f}")
print(f"  IDI = {nri_lr_rf['IDI']:.4f} "
      f"95%CI ({nri_lr_rf['IDI_CI'][0]:.4f}–{nri_lr_rf['IDI_CI'][1]:.4f}) "
      f"p={nri_lr_rf['IDI_p']:.4f}")

print(f"\n[NRI/IDI: RF→{best_name}]")
print(f"  NRI (continuous) = {nri_rf_best['NRI_cont']:.4f} "
      f"95%CI ({nri_rf_best['NRI_CI'][0]:.4f}–{nri_rf_best['NRI_CI'][1]:.4f}) "
      f"p={nri_rf_best['NRI_p']:.4f}")
print(f"  IDI = {nri_rf_best['IDI']:.4f} "
      f"95%CI ({nri_rf_best['IDI_CI'][0]:.4f}–{nri_rf_best['IDI_CI'][1]:.4f}) "
      f"p={nri_rf_best['IDI_p']:.4f}")

# ── 10. 전체 분석 완료 요약 ───────────────────────────────
print("\n" + "=" * 60)
print("전체 5단계 분석 완료 요약")
print("=" * 60)
print("""
저장된 파일 목록
─────────────────────────────────────────────────
[Step 1 - EDA]
  fig1_distributions.png      — 연속형 변수 분포
  fig2_binary_prevalence.png  — 이진형 위험인자 유병률
  fig3_correlation_heatmap.png— 상관관계 히트맵
  fig4_clinical_boxplot.png   — 주요 임상 지표 Boxplot
  fig5_outliers.png           — 이상치 탐지

[Step 2 - 단변량 분석]
  fig6_volcano_plot.png       — Volcano Plot
  fig7_forest_plot.png        — Unadjusted OR Forest Plot

[Step 3 - 다변량 로지스틱 회귀]
  fig8_aOR_forest_plot.png    — Adjusted OR Forest Plot
  fig9_lasso_path.png         — LASSO 정규화 경로

[Step 4 - ML 예측 모델]
  fig10_roc_curves.png        — ROC Curves (all models)
  fig11_model_comparison.png  — 모델 성능 비교
  fig12_confusion_matrix.png  — Confusion Matrix
  fig13_shap_beeswarm.png     — SHAP 설명가능성

[Step 5 - 임상 유용성]
  fig14_DCA.png               — Decision Curve Analysis
  fig15_calibration.png       — Calibration Plots
  fig16_clinical_impact.png   — Clinical Impact Curve
  fig17_threshold_optimization.png — 최적 임계값 분석
─────────────────────────────────────────────────

SCIE 논문 Methods 섹션 초안 (영문):
All statistical analyses were performed using Python 3.x.
Univariate associations were assessed using the
Mann-Whitney U test for continuous variables and
Fisher's exact test or chi-square test for categorical
variables, with Bonferroni correction for multiple
comparisons. Multivariable logistic regression was
performed including all a priori selected predictors,
and variable selection was additionally performed using
LASSO-penalised regression. Machine learning models
(Random Forest, XGBoost, LightGBM) were trained with
5-fold stratified cross-validation on the training set
(80%) and evaluated on a held-out test set (20%).
Model performance was assessed by AUROC with bootstrap
95% CI, sensitivity, specificity, PPV, and NPV.
Calibration was assessed using calibration curves and
the Brier score. Clinical utility was evaluated by
decision curve analysis (DCA) and net reclassification
improvement (NRI) and integrated discrimination
improvement (IDI). A two-sided p-value < 0.05 was
considered statistically significant. Reporting
followed the STROBE and TRIPOD guidelines.
""")
